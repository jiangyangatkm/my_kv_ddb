cd build
make clean
cd ..