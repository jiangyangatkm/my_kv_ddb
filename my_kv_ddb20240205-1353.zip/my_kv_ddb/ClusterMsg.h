#ifndef CLUSTERMSG_H
#define CLUSTERMSG_H

#pragma once

#define NET_IP_STR_LEN 46
#define CLUSTER_NAMELEN (NET_IP_STR_LEN + 6)

#define CLUSTER_PROTO_VER 1 /* Cluster bus protocol version. */

#define CLUSTERMSG_TYPE_PING 0          /* Ping */
#define CLUSTERMSG_TYPE_PONG 1          /* Pong (reply to Ping) */
#define CLUSTERMSG_TYPE_MEET 2          /* Meet "let's join" message */
#define CLUSTERMSG_TYPE_FAIL 3          /* Mark node xxx as failing */
#define CLUSTERMSG_TYPE_PUBLISH 4       /* Pub/Sub Publish propagation */
#define CLUSTERMSG_TYPE_FAILOVER_AUTH_REQUEST 5 /* May I failover? */
#define CLUSTERMSG_TYPE_FAILOVER_AUTH_ACK 6     /* Yes, you have my vote */
#define CLUSTERMSG_TYPE_FAILOVER_FINISH 7       /* 完成选举，由选票过半的节点广播 */
#define CLUSTERMSG_TYPE_FAILOVER_REVOTE 8       /* 重新选举，由第一个发现选举失败的从节点广播 */
#define CLUSTERMSG_TYPE_FAILOVER_INFO 9         /* 选举期间，用于各从节点间交换信息 */
#define CLUSTERMSG_TYPE_UPDATE 10        /* Another node slots configuration */
#define CLUSTERMSG_TYPE_MFSTART 11       /* Pause clients for manual failover */
#define CLUSTERMSG_TYPE_MODULE 12        /* Module cluster API message. */
#define CLUSTERMSG_TYPE_PUBLISHSHARD 13 /* Pub/Sub Publish shard propagation */
#define CLUSTERMSG_TYPE_COUNT 14       /* Total number of message types. */

typedef unsigned int uint32_t;
typedef unsigned short uint16_t;
typedef unsigned long int uint64_t;

typedef struct {
    char nodename[CLUSTER_NAMELEN];
    uint32_t ping_sent;
    uint32_t pong_received;
    char ip[NET_IP_STR_LEN];  /* IP address last time it was seen */
    uint16_t port;              /* primary port last time it was seen */
    uint16_t cport;             /* cluster port last time it was seen */
    uint16_t flags;             /* node->flags copy */
    uint16_t notused1;
    int16_t state;
} clusterMsgDataGossip;

typedef struct {
    char nodename[CLUSTER_NAMELEN];
} clusterMsgDataFail;

typedef struct {
    int epoch;
    char nodename[CLUSTER_NAMELEN]; // 选举针对的故障节点的名称
} clusterMsgDataFailover;

union clusterMsgData {
    /* PING, MEET and PONG */
    struct {
        /* Array of N clusterMsgDataGossip structures */
        clusterMsgDataGossip gossip[1];
        /* Extension data that can optionally be sent for ping/meet/pong
         * messages. We can't explicitly define them here though, since
         * the gossip array isn't the real length of the gossip data. */
    } ping;

    /* FAIL */
    struct {
        clusterMsgDataFail about;
    } fail;

    /* FAILOVER*/
    struct {
        clusterMsgDataFailover about;
    } failover;
};

typedef struct {
    char sig[4];        /* Signature "RCmb" (Redis Cluster message bus). */
    uint32_t totlen;    /* Total length of this message */
    uint16_t ver;       /* Protocol version, currently set to 1. */
    uint16_t port;      /* Primary port number (TCP or TLS). */
    uint16_t type;      /* Message type */
    uint16_t count;     /* Only used for some kind of messages. */

    uint64_t offset;    /* Master replication offset if node is a master or
                           processed replication offset if node is a slave. */
    uint32_t slave_count;
    uint32_t mac;
    uint32_t votes_count; // 从节点参与选举时已获得的选票数
    char slaveof[CLUSTER_NAMELEN];
    char myip[NET_IP_STR_LEN];    /* Sender IP, if not all zeroed. */

    uint16_t cport;      /* Sender TCP cluster bus port */
    uint16_t flags;      /* Sender node flags */

    bool is_slots_valid; //当slots无效时(对应无需更新)，跳过slots的同步
    uint16_t *slots;    // 存放slots的地址，反序列化时指向紧接着clusterMsg的内存
    union clusterMsgData *data; // 存放clusterMsgData的地址，反序列化时指向紧接着slots的内存
} clusterMsg;

#endif /*CLUSTERMSG_H*/