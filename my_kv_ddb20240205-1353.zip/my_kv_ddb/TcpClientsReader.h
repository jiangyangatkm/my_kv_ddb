#ifndef TCPCLIENTSREADER_H
#define TCPCLIENTSREADER_H

#pragma once

#include "EpollReader.h"

class TcpClientsReader
{
public:
    TcpClientsReader(EventLoop *eloop);
    ~TcpClientsReader();
public:
    int Start();
    bool IsRuning();
    void AddFd(int fd);
    void AddFd(int fd, SocketBuffer *buffer);
    const char *GetName();
private:
    EpollReader * m_reader;
    char m_server_name[256];
    bool m_is_running;
};

#endif