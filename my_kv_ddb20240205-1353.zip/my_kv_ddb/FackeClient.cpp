#include "FackeClient.h"
#include "DdbServer.h"

#include <string.h>

FackeClient::FackeClient(DdbServer *server)
 :DdbClient(server, nullptr, -1, nullptr)
{
    this->SetReplyEnable(false);
}

FackeClient::~FackeClient()
{

}

int FackeClient::ExecuteCmd(std::string cmd)
{
    strcpy(m_cmd, cmd.c_str());
    if(parse_cmd(m_cmd, strlen(m_cmd), m_argv, &m_argc)) {
        CmdExecutor * exe = m_server->GetCmdExecutor();
        m_ret = exe->Execute(this); // 执行命令
    }
    return m_ret;
}

void FackeClient::DoReply(const char *reply, int len)
{
    // char buf[1024];
    // memcpy(buf, reply, len);
    // buf[len] = 0;
    // printf("%s", buf);
}
