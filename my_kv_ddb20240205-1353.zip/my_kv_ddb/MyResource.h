#pragma once
#include "SocketBufferPool.h"
#include "EventLoop.h"

class MyResource
{
public:
	static SocketBufferPool *GetSocketBufferPool() {
		static SocketBufferPool pool;
		return &pool;
	}

	// static EventLoop *GetEventLoop() {
	// 	static EventLoop loop;
	// 	return &loop;
	// }
};

