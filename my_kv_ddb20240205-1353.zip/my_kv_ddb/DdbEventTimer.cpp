#include "DdbEventTimer.h"

#include "EventData.h"
#include "EventHelper.h"
#include "os_api.h"
#include "MyResource.h"

DdbTimerManager::DdbTimerManager(EventLoop *eloop) 
    : m_timer_count(0), m_timers(100), m_eloop(eloop)
{
}

void DdbTimerManager::on_event(DdbEvent *e)
{
    if(e->id != KV_DDB_EVENT_TIMER_TIMEOUT) return;
    
    DdbTimeEvent *te = (DdbTimeEvent*)e;
    TimerData *data = (TimerData*)te->data;
    int timer_id = data->timer_id;

    if(timer_id >= m_timers.size()) return;

    DdbTimerBase * timer = m_timers[timer_id];
    if(!timer) return;

    timer->on_timeout();
    if(timer->m_is_loop) {
        push_event(timer_id, timer);
    }
    else {
        timer->m_is_started = false;
    }
    
}

int DdbTimerManager::AddTimer(DdbTimerBase *timer, bool auto_start)
{
    // 查找可用的id
    int id = -1;
    for(id = 0; id < m_timers.size(); id++) {
        if(m_timers[id] == nullptr) break;
    }
    // 如果找不到，扩容
    if(id == -1) {
        id = m_timers.size();
        m_timers.resize(m_timers.size() * 2);
    }
    m_timers[id] = timer;
    timer->m_id = id;
    timer->m_mng = this;

    if(auto_start) {
        StartTimer(id);
    }

    return id;
}

void DdbTimerManager::StartTimer(int timer_id)
{
    if(timer_id >= m_timers.size() || timer_id < 0) return;
    DdbTimerBase *timer = m_timers[timer_id];
    if(timer == nullptr) return;
    if(timer->m_is_started) return;

    timer->m_is_started = true;
    push_event(timer_id, m_timers[timer_id]);
}

void DdbTimerManager::RemoveTimer(int timer_id)
{
    if(timer_id >= m_timers.size()) return;
    m_timers[timer_id] = nullptr;
}

void DdbTimerManager::push_event(int timer_id, DdbTimerBase *timer)
{
    long long timeout = mstime() + timer->m_interval;
    EventHelper::PushTimerEvent(m_eloop, timer_id, timeout);
}

void DdbTimerBase::Start()
{
    if(m_mng) m_mng->StartTimer(m_id);
}
