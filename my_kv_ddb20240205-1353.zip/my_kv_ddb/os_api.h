#ifndef OS_API_H
#define OS_API_H

#pragma once

long long ustime();
long long mstime();
void get_mstime_str(char *str_time, int len);
void get_mstime_str_2(char *str_time, int len);

#endif