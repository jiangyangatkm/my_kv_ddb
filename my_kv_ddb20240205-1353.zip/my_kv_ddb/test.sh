cd build

num=200
num_per_ip=40
ip_num=$(($num/$num_per_ip))

for((i=0;i<$ip_num;i++))
do
    ip4=$((128+$i))
    ip="192.168.227.""$ip4"
    for((j=0;j<$num_per_ip;j++))
    do
        port=$((8100+$j))
        ./my_kv_ddb $ip $port &
    done
done

cd ..

sleep 2

read -p "press q to quit: " input
while [ "$input" != "q" ]
do
    read -p "press q to quit: " input
done

killall my_kv_ddb
