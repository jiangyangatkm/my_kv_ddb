#include <stdio.h>
#include <iostream>
#include <string>
#include <vector>
#include <unistd.h>
#include <stddef.h>

#include "TcpServer.h"
#include "MyResource.h"
#include "ReadEventHandler.h"
#include "DdbServer.h"
#include "MyLog.h"
#include "os_api.h"
#include "gadgets.h"
#include "EventHelper.h"
#include "ClusterMsg.h"

using namespace std;

void *event_loop_target(void * param){
    EventLoop * eloop = (EventLoop*) param;
    eloop->Run();
    return nullptr;
}

void run_event_loop(EventLoop *eloop) {
    pthread_t th;
    int ret = pthread_create(&th, nullptr, event_loop_target, eloop);
    if(ret != 0){
        perror("run_event_loop");
    }
}

class TestHanlder: public EventHandler
{
public:
    void on_event(DdbEvent *e) {
        printf("%s delay timeout\n", get_str_time().c_str());
    }
};

void test_event_loop() {
    EventLoop eloop;
    TestHanlder handler;
    eloop.RegisterEventHanler(KV_DDB_EVENT_DELAY_TIMEOUT, &handler);
    run_event_loop(&eloop);
    while(getchar() != 'q') {
        EventHelper::PushDelayEvent(&eloop, nullptr, mstime() + 3000);
        EventHelper::PushDelayEvent(&eloop, nullptr, mstime() + 1000);
        EventHelper::PushDelayEvent(&eloop, nullptr, mstime() + 2000);
        
        printf("%s delay start\n", get_str_time().c_str());
    }
}

void test_ddb_server(const char* ip, unsigned short port) {
    DdbServerConfig config;
    config.ip = ip;
    config.main_port = port;
    config.cluster_port = config.main_port + CLUSTER_PORT_INC;
    config.mode = MODE_CLUSTER;
    // config.mode = MODE_NORMAL;
    config.repl_buf_size = 1024*1024; // 1Mbyte
    config.log_enable = false;

    DdbServer *server = new DdbServer;
    if(server->Initialize(&config) == 1) {
        printf("DdbServer %s is initialized successfully\n", server->GetName());
        server->Run();
    }
}

void test_ddb_server(int argc, char *argv[]) {
    if(argc > 3) {
        cout << "too many arguments" << endl;
        return;
    }
    if(argc == 3) {
        char *ip = argv[1];
        unsigned short port = atoi(argv[2]);
        if(port == 0) {
            cout << "part cannot be parsed" << endl;
            return;
        }  
        test_ddb_server(ip, port);  
    }
}

typedef struct {
    std::string ip;
    unsigned short port;
} Address;

void *ddb_server_target(void * param){
    Address * addr = (Address*)param;
    test_ddb_server(addr->ip.c_str(), addr->port);
    return nullptr;
}

void test_cluster()
{
    char ch;
    int node_num = 600;
    int num_per_ip = 40;
    int ip_num = node_num / num_per_ip;

    std::vector<Address> addr_array;
    assert(ip_num < 100);
    for(int i=0; i<ip_num; i++) {
        std::string ip = "192.168.227." + std::to_string(128 + i);
        for(int j=0; j<num_per_ip; j++) {
            unsigned short port = 8100 + j;
            Address addr;
            addr.ip = ip;
            addr.port = port;
            addr_array.push_back(addr);
        }
    }

    for(int i=0; i<addr_array.size(); i++) {
        pthread_t th;
        int ret = pthread_create(&th, nullptr, ddb_server_target, &addr_array[i]);
        if(ret != 0) {
            perror("pthread_create");
        }
    }

    while(true) {
        ch = getchar();
        if(ch == 'q') break;
    }
}

MyLog g_log("test_mylog.txt", 5);

void log(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    g_log.Log(fmt, ap);
    va_end(ap);
}

void test_log() {
    for(int i=0; i<6; i++) {
        log("log %d", i);
    }
}

void test_mt_random() {
    for(int i=0; i<5; i++) {
        int r = mt_random();
        printf("%d ", r);
    }

    printf("\n");
}

int main(int argc, char *argv[]){
    // test_ddb_server(argc, argv);
    // test_ddb_server(8000);
    test_cluster();
    // test_log();
    // test_event_loop();
    // printf("%d\n", offsetof(clusterMsg, port));
    // test_mt_random();
    return 0;
}
