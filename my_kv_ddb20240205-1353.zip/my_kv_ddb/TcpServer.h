#ifndef TCPSERVER_H
#define TCPSERVER_H

#pragma once

#include <string>
#include <sys/socket.h>
#include "EpollReader.h"

class TcpServer
{
public:
    TcpServer(std::string ip, unsigned short port, EventLoop *eloop);
    ~TcpServer();
public:
    int Start();
    const char *GetIp();
    unsigned short GetPort();
    bool IsRuning();
    int GetConnectNum();
    const char *GetName();
private:
    void make_server_name(char *out_name, std::string ip, unsigned short port);
private:
    //struct sockaddr m_addr;
    std::string m_ip;
    unsigned short m_port;

    int m_listener_fd;

    EpollReader * m_reader;
    char m_server_name[256];

    bool m_is_running;
};

#endif