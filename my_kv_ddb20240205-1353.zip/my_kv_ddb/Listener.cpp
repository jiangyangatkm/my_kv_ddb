#include "Listener.h"

Listener::Listener()
{

}

Listener::~Listener()
{

}

int Listener::accept()
{
    return 0;
}
