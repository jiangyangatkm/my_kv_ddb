#ifndef EVENTDATA_H
#define EVENTDATA_H

#pragma once

#include <sys/socket.h>
#include "EventBase.h"

#define KV_DDB_EVENT_SOCKET                 0x100
#define KV_DDB_EVENT_TIME                   0x200

#define KV_DDB_EVENT_SOCKET_ACCEPTED        (KV_DDB_EVENT_SOCKET | 1)
#define KV_DDB_EVENT_SOCKET_READ            (KV_DDB_EVENT_SOCKET | 2)
#define KV_DDB_EVENT_SOCKET_READ_ERROR      (KV_DDB_EVENT_SOCKET | 3)
#define KV_DDB_EVENT_SOCKET_WRITE_ERROR     (KV_DDB_EVENT_SOCKET | 4)

#define KV_DDB_EVENT_TIMER_TIMEOUT          (KV_DDB_EVENT_TIME | 1)
#define KV_DDB_EVENT_DELAY_TIMEOUT          (KV_DDB_EVENT_TIME | 2)

class SockDataBase : public EventDataBase
{
public:
    int sfd; // 套接字描述符
    char * server_name; // 指向tcp服务器的名字
};

class SockAcceptData: public SockDataBase
{
public:
    struct sockaddr addr; // 客户端地址
    socklen_t addr_len; // 客户端地址长度
    void * data; // 指向数据接受缓冲对象的指针
};

class SockReadData: public SockDataBase
{
public:
    void * data; // 指向数据接收缓冲对象的指针
};

class SockErrorData: public SockDataBase
{
public:
    void * data; // 指向数据接收缓冲对象的指针
    int error_code; // 返回的故障码
};

class TimerData: public EventDataBase {
public:
    int timer_id;
};

class DelayData: public EventDataBase {
public:
    DelayData() : data(nullptr) {}
    void *data;
};

#endif