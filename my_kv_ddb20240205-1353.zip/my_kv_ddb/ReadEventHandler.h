#ifndef READEVENTHANDLER_H
#define READEVENTHANDLER_H

#pragma once

#include "EventLoop.h"
#include "EventData.h"

class ReadEventHandler: public EventHandler
{
public:
    ReadEventHandler();
    ~ReadEventHandler();
protected:
    void on_event(DdbEvent *e);
private:

};

#endif