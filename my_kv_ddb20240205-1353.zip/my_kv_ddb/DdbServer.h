#ifndef DDBSERVER_H
#define DDBSERVER_H

#pragma once

#include <list>
#include <unordered_map>
#include <unordered_set>
#include <set>
#include <string>
#include <vector>
#include <sys/epoll.h>
#include "tools/RingBuffer.h"
#include "DdbClient.h"
#include "FackeClient.h"
#include "ClusterNode.h"
#include "TcpServer.h"
#include "TcpClientsReader.h"
#include "EventBase.h"
#include "CmdExecutor.h"
#include "DdbEventTimer.h"
#include "MyLog.h"


#define MODE_NORMAL                     0
#define MODE_CLUSTER                    1

#define CLUSTER_PORT_INC                10000
#define CLUSTER_ALL_SLOTS_NUM           (1 << 14)
#define BYTE_BITS_NUM                   8

#define DDB_INFO_FLAG_BASIC             1
#define DDB_INFO_FLAG_NODE              2
#define DDB_INFO_FLAG_SLOT              4
#define DDB_INFO_FLAG_ALL               (DDB_INFO_FLAG_BASIC|DDB_INFO_FLAG_NODE|DDB_INFO_FLAG_SLOT)

#define FAILOVER_REQUEST_MAX_DELAY      2000

using DdbStrPair = std::pair<std::string, std::string>;
using DdbDict = std::unordered_map<std::string, std::string>;
using DdbDictPair = DdbStrPair;
using DdbInfo = std::list<DdbStrPair>;
using UShortSet = std::unordered_set<unsigned short>;
using NodeFdDict = std::unordered_map<int, ClusterNode *>;
using NodeNameDict = std::unordered_map<std::string, ClusterNode *>;
using NodeSet = std::unordered_set<ClusterNode *>;
using NodeTimeSet = std::set<ClusterNode *, NodeTimeCompare>;
using IntPair = std::pair<int, int>;
using IntPairList = std::list<IntPair>;
// using NodeTimeSet = std::set<ClusterNode *>;

class DdbServerConfig
{
public:
    std::string ip;
    unsigned int main_port;
    unsigned int cluster_port;
    unsigned int mode; // 0-非集群，1-集群
    unsigned int repl_buf_size;
    bool log_enable;
};

class DdbServer : public EventHandler
{
    class TimerHandler;
    class FailoverRequestAlarm;
    class Server;
    class Cluster;
    class Master;
    class AsClients;
    class SocketReader;

public:
    enum State
    {
        S_MASTER = 1,
        S_SYNC,
        S_SLAVE
    };

public:
    DdbServer();
    ~DdbServer();

public:
    int Initialize(DdbServerConfig * config = nullptr);
    void Log(const char *fmt, ...);
    void LogNode(ClusterNode *node, std::string info); // 测试用
    void LogNode2(ClusterNode *node, std::string info); // debug
    void Run();

    unsigned int GetMode() { return m_mode; }
    State GetState() { return m_state; }

    EventLoop *GetEventLoop() { return &m_eloop; }

    CmdExecutor *GetCmdExecutor() { return &m_cmd_executor; }

    void Set(std::string key, std::string value);
    std::string Get(std::string key);
    void Erase(std::string key);
    bool ContainKey(std::string key);
    int Size();
    void ClearAll();
    bool IsMutiSlots();
    int GetDbNum() { return m_slots_set.size(); }
    void AddSlots(IntPairList slots);

    const char *GetName();
    const char *GetClusterServerName();
    std::string GetMasterName();
    void GetInfo(DdbInfo *out_info);
    void GetClusterInfo(DdbInfo *out_info, int flags);
    void GetSyncState(ClusterSyncState *out_state);

    int Set(DdbClient *client);
    int Get(DdbClient *client);
    int SlaveOf(DdbClient *client);
    void SlaveOf(std::string ip, unsigned short port);
    int SlaveOfNoOne(DdbClient *client);
    void SlaveOfNoOne();
    int FullSync(DdbClient *client);
    int PartSync(DdbClient *client);
    void Replicate(std::string &cmd);
    void ReplicateToMaster(std::string &cmd);
    void FeedReplicateBuffer(std::string &cmd);
    int Meet(std::string ip, unsigned short port);

    int do_address_check(DdbClient *client, std::string ip, std::string sport);

    NodeSet &GetPfailNodes() { return m_cluster->m_pfail_nodes; }
    NodeFdDict &GetNodeFdDict() { return m_cluster->m_nodes; }
    NodeNameDict &GetNodeNameDict() { return m_cluster->m_nodes_2; }
    const NodeTimeSet &GetPingTimeSet() { return m_cluster->m_ping_time_set; }
    const NodeNameDict &GetFailNodes() { return m_cluster->m_fail_nodes; }
    ClusterNode *GetFailNode(std::string name);
    void AddNode(ClusterNode * node);
    bool AddNode2(ClusterNode * node);
    void AddNodeToPingSet(ClusterNode * node);
    void RemoveNode(ClusterNode * node); // 不包括垃圾回收
    void AddPfailNode(ClusterNode * node) { m_cluster->m_pfail_nodes.emplace(node); }
    void RemovePfailNode(ClusterNode * node) { m_cluster->m_pfail_nodes.erase(node); }
    void MoveToFailSet(ClusterNode * node);
    void AddMeetingNode(ClusterNode * node);
    void RemoveMeetingNode(ClusterNode * node);
    void UpdatePingTime(mstime_t new_time, ClusterNode * node);
    void UpdateSlots(ClusterNode * node, UShortSet * slots);
    void ClearSlots(UShortSet * slots);
    bool IsUsable();
    void IncreaseVotes() { m_cluster->m_votes_count++; }
    void ResetVotes() { m_cluster->m_votes_count = 0; }
    int GetVotesCount() { return m_cluster->m_votes_count; }
    void FailToAll(std::string name);
    void FailoverRequest();
    void FailoverRequestDelayed();
    void FailoverToAll(int msg_type, ClusterNode *fail_node);
    bool IsVoting() { return m_cluster->m_is_voting; }
    void FinishVote();
    void SetFqAlarm(int ms);
    int GetMasterCount() { return m_cluster->m_master_count; }
    int GetEpoch();
    void MarkNodesSlotsChanged() { mark_slots_changed_to_nodes(); }

    // debug
    int GetAssignedSlotsNum();
    std::string GetSlotsInfo();
    int Test(DdbClient *client);
public:
    void on_event(DdbEvent *e);

private:
    void cron();
    bool load_config(DdbServerConfig *config);

    int connect_master(const char *ip, unsigned short port);
    int send_to_master(const char *data, int len);
    void do_reply(DdbClient *client, std::string reply)
    {
        client->DoReply(reply.c_str(), reply.length());
    }

    void create_dbs(int size);
    void release_dbs();
    void create_normal_dbs();
    void create_cluster_dbs();
    int key_to_slot(std::string key);
    int parse_slot(std::string key);
    void set(int slot, std::string key, std::string value);
    std::string get(int slot, std::string key);
    void erase(int slot, std::string key);
    void clear(int slot);
    bool contain_key(int slot, std::string key);
    size_t size(int slot);
    int try_redirect(DdbClient *client, int slot);
    int parse_slot_and_redirect(DdbClient *client, std::string key);

    void add_slot(int slot);
    void remove_slot(int slot);
    void add_slots(int start_slot, int count);
    void mark_slots_changed_to_nodes();
    void update_cluster_slots(ClusterNode *node, unsigned short slot);

    std::string to_mode_name(int mode);
    std::string to_state_name(State state);

    void addinfo(DdbInfo *info, std::string name, std::string state);
private:
    FackeClient m_fake_client;
    MyLog *m_log;

    unsigned int m_mode;
    State m_state;

    DdbDict **m_dbs;
    unsigned int m_dbs_size;
    UShortSet m_slots_set;

    bool m_is_initialized;
    // 处理对象映射表，通过这个表将不同TcpServer产生的事件
    // 分发给对应的处理对象，这里使用了一个技巧，利用TcpServer
    // server_name指针的唯一性，实现key的唯一性
    EventLoop m_eloop;
    std::unordered_map<const char *, EventHandler *> m_handler_map;
    TimerHandler *m_timer_handler;
    FailoverRequestAlarm *m_fq_alarm;
    Server *m_server;
    Cluster *m_cluster;
    Master *m_master;
    AsClients *m_ascliets;

    TcpServer *m_normal_tcpserver;     // 用于普通业务的通讯
    TcpServer *m_cluster_tcpserver;    // 用于集群通讯
    TcpClientsReader m_clients_reader; // 用于本机作为客户端时产生读事件

    CmdExecutor m_cmd_executor;

    long long m_repl_offset; // 复制偏移量
    RingBuffer *m_repl_buf;// 积压缓冲区
    // Cron定时器
    class CronTimer: public DdbTimerBase
    {
    public:
        CronTimer(DdbServer *server) 
            : m_server(server), DdbTimerBase(1000, true) {}
        void on_timeout();
    private:
        DdbServer *m_server;
    };
    // FailoverRequest定时器
    class FailoverRequestAlarm: public EventHandler
    {
    public:
        FailoverRequestAlarm(DdbServer *server) 
            : m_server(server) {}
       void on_event(DdbEvent *e);

        void SetAlarm(int epoch, int m_delay);
    private:
        DdbServer *m_server;
    };
    // 处理定时事件
    class TimerHandler: public EventHandler
    {
    public:
        TimerHandler(DdbServer *server);
        void on_event(DdbEvent *e);
    public:
        CronTimer m_cron_timer;
        DdbTimerManager m_timer_mng;
    private:
        DdbServer *m_server;
    };
    // 处理业务
    class Server : public EventHandler
    {
    public:
        Server(DdbServer *server) : m_server(server) {}
        void on_event(DdbEvent *e);

    public:
        std::unordered_map<int, DdbClient *> m_clients;
        std::unordered_map<int, DdbClient *> m_slaves;

    private:
        DdbServer *m_server;
    };

    // 处理集群
    class Cluster : public EventHandler
    {
    public:
        Cluster(DdbServer *server) 
            : m_server(server), m_slots(CLUSTER_ALL_SLOTS_NUM), 
            m_assigned_slots_count(0), m_self(0, 0, 0), 
            m_votes_count(0), m_master_count(0), m_is_voting(false) {}
        void on_event(DdbEvent *e);

    public:
        NodeFdDict m_nodes;
        NodeNameDict m_nodes_2; // 以name为键
        NodeNameDict m_nodes_3; // 以cluster name为键
        NodeSet m_pfail_nodes;
        NodeNameDict m_fail_nodes;
        NodeTimeSet m_ping_time_set; // 用于加速查找
        NodeNameDict m_meeting_nodes; // 以cluster name为键
        NodeSet m_to_delete_nodes; // 保存待删除节点，为避免对象自杀，
                                   // 需要删除的节点统一在cron中处理
        std::vector<ClusterNode*> m_slots; // 用于快速查找槽对应的节点
        int m_assigned_slots_count;
        ClusterNode m_self; // 只是为了处理m_slots方便，无其他作用

        // 仅在选举期间有效
        unsigned int m_votes_count;
        unsigned int m_master_count; 
        bool m_is_voting;
        NodeSet m_electors;

        //debug
        StrSet d_node_names;
    private:
        DdbServer *m_server;
    };

    // 处理master
    class Master : public EventHandler
    {
    public:
        Master(DdbServer *server)
            : m_server(server), m_master_port(0),
              m_fd_to_master(-1), m_client(nullptr), m_master_mode(MODE_NORMAL) {}

        void on_event(DdbEvent *e);

        void Reset();
        std::string GetMasterName();
    public:
        std::string m_master_ip;
        unsigned short m_master_port;
        int m_fd_to_master;
        int m_master_mode;

        DdbClient *m_client; // 用于执行master发来的命令
    private:
        DdbServer *m_server;
    };

    // 处理作为客户端收到的数据
    class AsClients : public EventHandler
    {
    public:
        AsClients(DdbServer *server) : m_server(server) {}
        void on_event(DdbEvent *e);
    private:
        DdbServer *m_server;
    };

    class SocketReader
    {
    public:
        SocketReader(int sfd, SocketBuffer *buffer);
        ~SocketReader();
        std::string Readline();
        int ReadSomeBytes(char *buf, int len);
        int WaitSomeBytes(int len);
    private:
        SocketBuffer *m_buffer;
        int m_sfd;

        int m_epfd;
        struct epoll_event m_events[1];
    };
};

#endif