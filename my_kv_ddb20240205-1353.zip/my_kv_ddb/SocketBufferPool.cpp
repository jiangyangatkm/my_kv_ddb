#include "SocketBufferPool.h"

#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <assert.h>
#include <sys/ioctl.h>

SocketBuffer::SocketBuffer(int capacity)
    : m_start(0), m_end(0), m_buf(capacity)
{
}

int SocketBuffer::ReadOut(char* out_buf, int len)
{
    int end = m_end; // 记录end，确保操作过程中end不变
    int start = m_start;// 虽然只有ReadOut会改变m_start的值，还是记录一下，以确保start不变
    int capacity = Capacity();// 记录容量
    // 计算读取结束点read_end和读取长度len
    int read_end = start + len;
    if (end < start) end += capacity;
    if (read_end > end) read_end = end;
    len = (read_end - start) % capacity;// 计算实际读取长度
    read_end = read_end % capacity;// 如果超出范围，取余数

    if (start < read_end) {
        memcpy(out_buf, &m_buf[start], len * sizeof(char));
    }
    else if (start > read_end) {
        int first_len = capacity - start;
        memcpy(out_buf, &m_buf[start], first_len);// 先拷贝第一段
        memcpy(out_buf + first_len, &m_buf[0], len - first_len); // 再拷贝第二段
    }

    m_start = read_end;// 标记新的m_start

    return len;
}

static int get_bytes_num_in_rbuffer(int s)
{
    int bytesInBuffer;
    if (::ioctl(s, TIOCINQ, &bytesInBuffer) == -1) {
        return -1;
    }
    return bytesInBuffer;
}

int SocketBuffer::WriteIn(int s)
{
    int len = 0;
    int end = m_end; // 虽然只有ReadOut会改变m_end的值，还是记录一下，以确保end不变
    int start = m_start;// 记录start，确保操作过程中start不变
    int capacity = Capacity();// 记录容量
    if (end < start - 1) {
        len = read(s, &m_buf[end], start - end - 1); // 保留一个字节防止end,start重合
    }
    else if (end >= start) {
        if (start == 0) {
            len = read(s, &m_buf[end], capacity - end - 1); // 保留一个字节防止end,start重合
        }
        else if((end - start) < (capacity - 1)) { // 缓冲区未满
            // 尝试第一次读取
            int first_len = capacity - end;
            len = read(s, &m_buf[end], first_len);
            // 读满则可能还有数据，将数据继续读入缓冲区，
            // 读取前先判断一下接收缓冲里是否还有数据，
            // 否则会一直阻塞在这里知道下一波数据到来
            if (len == first_len && get_bytes_num_in_rbuffer(s) > 0) {
                int temp_len = read(s, &m_buf[0], start - 1); // 保留一个字节防止end,start重合
                if (temp_len < 0) {
                    len = temp_len;
                }
                else {
                    len += temp_len;
                }
            }
        }
    }

    if(len > 0) m_end = (m_end + len) % capacity; // 更新m_end

    return len;
}

void SocketBuffer::Reset()
{
    m_start = m_end = 0;
}

int SocketBuffer::Capacity()
{
    return m_buf.capacity();
}

bool SocketBuffer::IsFull()
{
    int c = Capacity();
    int d = m_start - m_end;
    return (d == 1) || (d == -c + 1);
}

int SocketBuffer::Size()
{ 
    int c = Capacity();
    int d = m_end - m_start;
    if(d < 0) d = d + c;
    return d;
}

SocketBufferPool::~SocketBufferPool()
{
    m_pool_lock.lock();
    for (SocketBuffer* buf : m_pool) {
        delete buf;
    }
    m_pool_lock.unlock();
}

SocketBuffer* SocketBufferPool::GetBuffer()
{
    SocketBuffer* buf = get_unused_buf();
    if(buf == nullptr) {
        buf = new SocketBuffer();
        m_pool_lock.lock();
        m_pool.push_back(buf);
        m_pool_lock.unlock();
    }

    return buf;
}

void SocketBufferPool::ReturnBuffer(SocketBuffer* buf)
{
    if(buf == nullptr) return;
    return_unused_buf(buf);
}

SocketBuffer *SocketBufferPool::get_unused_buf()
{
    SocketBuffer * buf = nullptr;

    m_unused_lock.lock();
    if(m_unused_buf.size() > 0) {
        buf = *m_unused_buf.begin();
    }
    m_unused_buf.erase(buf);
    m_unused_lock.unlock();

    return buf;
}

void SocketBufferPool::return_unused_buf(SocketBuffer* buf)
{
    assert(buf != nullptr);

    m_unused_lock.lock();
    buf->Reset();
    m_unused_buf.emplace(buf);
    m_unused_lock.unlock();
}
