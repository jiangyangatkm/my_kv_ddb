#ifndef GADGETS_H
#define GADGETS_H

#pragma once

#include <string>
#include <sstream>
#include <vector>
#include <unordered_map>
#include <random>
#include <algorithm>
#include <assert.h>

#include "os_api.h"

long long my_strtoll(const char *str, bool *is_ok = nullptr, int base = 10);
int my_strtoi(const char *str, bool *is_ok = nullptr, int base = 10);

std::vector<std::string> my_strsplit(const std::string& str, char delim);

unsigned short crc(std::string key);

template<typename T>
void set_flag(T &arg, int flag) {
    arg |= flag;
}

template<typename T>
void clear_flag(T &arg, int flag) {
    arg &= ~flag;
}

template<typename T>
bool get_flag(T arg, int flag) {
    return arg & flag;
}

template<typename TK, typename TV>
std::vector<TK> get_keys_by_random(std::unordered_map<TK, TV> &map, int n) {
    assert(map.size() >= n);

    std::vector<TK> keys;
    for(std::pair<TK, TV> pair: map) {
        keys.push_back(pair.first);
    }

    std::random_device rd;
    std::mt19937 g(rd());
    std::shuffle(keys.begin(), keys.end(), g);
    return std::vector<TK>(keys.begin(), keys.begin() + n);
}

int mt_random();

std::string get_str_time();

#endif