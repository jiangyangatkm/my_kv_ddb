#include "TcpClientsReader.h"

#include <string.h>

TcpClientsReader::TcpClientsReader(EventLoop *eloop)
    : m_reader(nullptr), m_is_running(false)
{
    // 初始化名称
    memset(m_server_name, 0, sizeof(m_server_name));
    strcpy(m_server_name, "clients");
    m_reader = new EpollReader(m_server_name, eloop);
}

TcpClientsReader::~TcpClientsReader()
{
    if(m_reader != nullptr) delete m_reader;
}

int TcpClientsReader::Start()
{
    if(IsRuning()) return 0;
    m_is_running = true;
    m_reader->Start();
    return 1;
}

bool TcpClientsReader::IsRuning()
{
    return m_is_running;
}

void TcpClientsReader::AddFd(int fd)
{
    m_reader->AddFd(fd);
}

void TcpClientsReader::AddFd(int fd, SocketBuffer * buffer)
{
    m_reader->AddFd(fd, buffer);
}

const char *TcpClientsReader::GetName()
{
    return m_server_name;
}
