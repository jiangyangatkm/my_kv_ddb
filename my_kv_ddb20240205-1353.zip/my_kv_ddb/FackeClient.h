#ifndef FACKECLIENT_H
#define FACKECLIENT_H

#pragma once
#include "DdbClient.h"

class FackeClient : private DdbClient
{
public:
    FackeClient(DdbServer *server);
    ~FackeClient();

    int ExecuteCmd(std::string cmd);
    virtual void DoReply(const char *reply, int len);
private:

};

#endif