#ifndef CMDEXECUTOR_H
#define CMDEXECUTOR_H

#pragma once

#include <unordered_map>
#include <string>

class DdbServer;
class DdbClient;

typedef int (*CmdFunction)(DdbClient *client);

enum CommandType {
    CT_NORMAL = 1, CT_REPLICATION,
};

class Command {
public:
    Command()
    : fun(nullptr), type(CT_NORMAL) {}
    Command(CmdFunction fun, CommandType type) 
    : fun(fun), type(type) {}
    Command(Command& c) 
    : fun(c.fun), type(c.type) {}

    CmdFunction fun;
    CommandType type;
};

class CmdExecutor
{
public:
    CmdExecutor();
    ~CmdExecutor();

    int Execute(DdbClient *client);
    bool IsContainCmd(std::string cmd);
private:
    std::unordered_map<std::string, Command> m_cmd_table;
    std::unordered_map<std::string, Command> m_cluster_cmd_table;
};

#endif