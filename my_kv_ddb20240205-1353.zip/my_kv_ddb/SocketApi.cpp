#include "SocketApi.h"

#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/un.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <netdb.h>
#include <errno.h>
#include <stdarg.h>
#include <stdio.h>
#include <signal.h>
#include <sys/ioctl.h>

int SocketApi::connect(const char *ip, unsigned short port, const char *local_ip)
{
    int s = SOCKET_EER, rv;
    char portstr[6];  /* strlen("65535") + 1; */
    struct addrinfo hints, *servinfo, *bservinfo, *p, *b;

    snprintf(portstr,sizeof(portstr),"%d",port);
    memset(&hints,0,sizeof(hints));
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;

    if ((rv = getaddrinfo(ip,portstr,&hints,&servinfo)) != 0) {
        // printf(gai_strerror(rv));
        printf("connect: ip %s error: %s\n", ip, gai_strerror(rv));
        return SOCKET_EER;
    }
    for (p = servinfo; p != NULL; p = p->ai_next) {

        if ((s = socket(p->ai_family,p->ai_socktype,p->ai_protocol)) == -1)
            continue;
        if (local_ip) {
            bool bound_ok = false;
            if ((rv = getaddrinfo(local_ip, NULL, &hints, &bservinfo)) != 0)
            {
                // printf(gai_strerror(rv));
                printf("connect: local ip %s error: %s\n", ip, gai_strerror(rv));
                goto error;
            }
            for (b = bservinfo; b != NULL; b = b->ai_next) {
                if (bind(s,b->ai_addr,b->ai_addrlen) != -1) {
                    bound_ok = true;
                    break;
                }
            }
            freeaddrinfo(bservinfo);
            if (!bound_ok) {
                perror("bind:");
                goto error;
            }
        }
        if (::connect(s,p->ai_addr,p->ai_addrlen) == -1) {
            close(s);
            s = SOCKET_EER;
            continue;
        }

        // 成功建立一个连接，转到end返回
        goto end;
    }
    if (p == NULL) {
        printf("connect to %s:%d error: %s\n", ip, port, gai_strerror(rv));
    }
        // perror("socket create:");

error:
    if (s != SOCKET_EER) {
        close(s);
        s = SOCKET_EER;
    }

end:
    freeaddrinfo(servinfo);
    return s;
}

int SocketApi::create_server(const char *ip, unsigned short port)
{
    int s = SOCKET_EER, rv;
    char portstr[6];  /* strlen("65535") + 1; */
    struct addrinfo hints, *servinfo, *p;

    snprintf(portstr,sizeof(portstr),"%d",port);
    memset(&hints,0,sizeof(hints));
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;

    if ((rv = getaddrinfo(ip,portstr,&hints,&servinfo)) != 0) {
        printf("create_servet: ip %s error: %s\n", ip, gai_strerror(rv));
        return SOCKET_EER;
    }

    bool bound_ok = false;
    for (p = servinfo; p != NULL; p = p->ai_next) {
        if ((s = socket(p->ai_family,p->ai_socktype,p->ai_protocol)) == -1)
            continue; 
        if (bind(s,p->ai_addr,p->ai_addrlen) != -1) {
            bound_ok = true;
            break;
        }
        if (!bound_ok) {
            perror("bind:");
        }
    }
    if (p == NULL)
        perror("socket create:");

    if(bound_ok == false) {
        if (s != SOCKET_EER) {
            close(s);
            s = SOCKET_EER;
        }
    }

    freeaddrinfo(servinfo);
    return s;
}

int SocketApi::listen(int s, int n)
{
    return ::listen(s, n);
}

int SocketApi::send(int s, const char *buf, int len)
{
    return ::send(s, buf, len, MSG_NOSIGNAL);
}

int SocketApi::recv(int s, char *buf, int len)
{
    return ::recv(s, buf, len, 0);
}

int SocketApi::send_with_timeout(int s, const char *buf, int len, int ms)
{
    struct timeval tv, old_tv;
    socklen_t old_len;

    getsockopt(s, SOL_SOCKET, SO_SNDTIMEO, &old_tv, &old_len);

    tv.tv_sec = ms / 1000;
    tv.tv_usec = (ms % 1000) * 10000;
    setsockopt(s, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
    ::write(s, buf, len);
    setsockopt(s, SOL_SOCKET, SO_SNDTIMEO, &old_tv, sizeof(old_tv));

    return 0;
}

int SocketApi::recv_with_timeout(int s, char *buf, int len, int ms)
{
    struct timeval tv, old_tv;
    socklen_t old_len;
    int ret;

    getsockopt(s, SOL_SOCKET, SO_RCVTIMEO, &old_tv, &old_len);

    tv.tv_sec = ms / 1000;
    tv.tv_usec = (ms % 1000) * 10000;
    setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    ret = ::read(s, buf, len);
    setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, &old_tv, sizeof(old_tv));

    return ret;
}

void SocketApi::close(int s)
{
    ::close(s);
}

int SocketApi::get_bytes_num_in_sbuffer(int s)
{
    int bytesInBuffer;
    if (::ioctl(s, TIOCOUTQ, &bytesInBuffer) == -1) {
        return -1;
    }
    return bytesInBuffer;
}

int SocketApi::get_bytes_num_in_rbuffer(int s)
{
    int bytesInBuffer;
    if (::ioctl(s, TIOCINQ, &bytesInBuffer) == -1) {
        return -1;
    }
    return bytesInBuffer;
}
