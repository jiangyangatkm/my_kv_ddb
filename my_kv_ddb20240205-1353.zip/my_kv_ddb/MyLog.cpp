#include "MyLog.h"

#include <errno.h>

#include "os_api.h"

MyLog::MyLog(const char *file_name, int max_log_count)
    : m_file_name(file_name), m_max_count(max_log_count), m_log_count(0)
{
}

MyLog::~MyLog()
{

}

void MyLog::Log(const char *fmt, __gnuc_va_list arg)
{
    if(m_log_count >= m_max_count) {
        printf("log overflow: max log count is %d\n", m_max_count);
        return;
    }

    char msg[LOG_MAX_LEN];
    char str_time[80];
    FILE *fp;

    vsnprintf(msg, sizeof(msg), fmt, arg);
    get_mstime_str(str_time, sizeof(str_time));
    fp = fopen(m_file_name.c_str(), "a");
    if(fp == nullptr) {
        perror("cannot open file:");
        return;
    }
    fprintf(fp,"%s: %s\n", str_time, msg);
    fflush(fp);
    fclose(fp);

    m_log_count++;
}

void MyLog::Log(const char *fmt, ...)
{  
    va_list ap;
    va_start(ap, fmt);
    Log(fmt, ap);
    va_end(ap);
}

void MyLog::Clear()
{
    FILE *fp;
    if((fp = fopen(m_file_name.c_str(), "w")) != nullptr) {
        fclose(fp);
    }
}
