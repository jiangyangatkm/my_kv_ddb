#include "DdbClient.h"
#include "DdbServer.h"

#include <string.h>
#include <unistd.h>
#include <unordered_set>
#include "SocketApi.h"
#include "EventData.h"
#include "EventHelper.h"
#include "MyResource.h"

DdbClient::DdbClient(DdbServer *server, char *server_name, int sfd, SocketBuffer * buffer)
    : m_server(server), m_server_name(server_name), m_sfd(sfd), m_in_buffer(buffer), 
      m_is_valid(true), m_is_reply(true), m_flags(0), m_preprocessor(nullptr), 
      m_postprocessor(nullptr)
{
    memset(m_cmd, 0, sizeof(m_cmd));
}

DdbClient::~DdbClient()
{

}

void DdbClient::DoRead()
{
    int ret, len, i;

    if(!m_is_valid) return;
    if(m_sfd < 0) return;

    while(true) {
        // 读取命令
        ret = try_read_cmd();
        if(ret < 0) { // 命令长度超限
            goto Error;
        }
        else if(ret == 0) { // 缓冲区读不到完整的命令
            break;
        }
        // 解析命令
        if(!parse_cmd(m_cmd, strlen(m_cmd), m_argv, &m_argc)) {
            goto Error;
        }

        CmdExecutor * exe = m_server->GetCmdExecutor();
        execute_processor(m_preprocessor) ; // 调用预处理器
        m_ret = exe->Execute(this); // 执行命令
        execute_processor(m_postprocessor); // 调用后处理器
    }

    return;

Error:
    const char reply[256] = "format error: server will close!\n";
    this->DoReply(reply, strlen(reply));
    close(m_sfd); 
    // close不会触发读错误事件,需要伪造一个读错误来清理关闭的连接
    EventHelper::PushReadErrorEvent(
        m_server->GetEventLoop(), m_sfd, m_server_name, m_in_buffer, 0);
    // 设置为无效，这样即使ReadErrorEvent事件异步到达，也不会产生写错误
    m_is_valid = false;
}

void DdbClient::DoReply(const char *reply, int len)
{
    if(!m_is_valid) return;
    if(!m_is_reply) return;
    if(m_sfd < 0) return;

    SocketApi::send(m_sfd, reply, len);
}

void DdbClient::SetReplyEnable(bool enable)
{
    m_is_reply = enable;
}

bool DdbClient::parse_cmd(char *cmd, int cmd_len, char *argv[], int *argc)
{
    int len = cmd_len;
    char pre = '\0';

    auto is_visible = [](char c){
        return c >= '!' && c <= '~';
    };

    *argc = 0;
    for(int i = 0; i<len; i++) {
        char c = cmd[i];
        if(is_visible(c)){
            if(!is_visible(pre)) {
                if(*argc >= MAX_ARG_NUM) { // 参数过多
                    return false;
                }
                argv[*argc] = cmd + i;
                (*argc)++;
            }
        }
        else {
            cmd[i] = '\0';
        }
        pre = c;
    }

    return true;
}

int DdbClient::try_read_cmd()
{
    int start = m_in_buffer->Start();
    int end = m_in_buffer->End();
    int capacity = m_in_buffer->Capacity();

    int len = 0;
    if(start > end) end += capacity;
    for(int i=start; i<end; i++){
        if(m_in_buffer->At(i) == '\n'){
            len = i - start + 1;
            break;
        }
    }

    if(len <= MAX_CMD_LEN){
        len = m_in_buffer->ReadOut(m_cmd, len);
        m_cmd[len - 1] = '\0'; // 将'\n'替换为‘\0’
    }
    else{
        len = -1;
    }
    
    return len;
}

void DdbClient::execute_processor(ICmdProcessor *processor)
{
    if(!processor) return;
    if(m_server->GetCmdExecutor()->IsContainCmd(m_argv[0])) {
        processor->Execute(this);
    }
}
