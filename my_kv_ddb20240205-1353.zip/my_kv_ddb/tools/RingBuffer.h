#ifndef RINGBUFFER_H
#define RINGBUFFER_H

#pragma once

class RingBuffer
{
public:
    RingBuffer(int capacity = 1024);
    ~RingBuffer();
public:
    int WriteIn(char *buf, int len);
    int ReadOut(char *buf, int len);
    int Copy(char *buf, int offset, int len);
    int WriteInSafe(char *buf, int len);
    int ReadOutSafe(char *buf, int len);

    int Capacity() { return m_capacity; }
    int Start() { return m_start; }
    int End() { return m_end; }
    int Size();
private:
    char *m_buf;
    int m_capacity;
    int m_buf_size;
    int m_start;
    int m_end;
    
};

#endif