#pragma once
#include <queue>
#include <mutex>

template<typename T>
class concurrent_queue
{
public:
	void push(T element) {
		m_mutex.lock();
		m_queue.push(element);
		m_mutex.unlock();
	}

	T pop() {
		T element = T{};

		m_mutex.lock();	
		if(!m_queue.empty()) {
			element = m_queue.front();
			m_queue.pop();
			m_mutex.unlock();
			return element;
		}
		m_mutex.unlock();

		return element;
	}

	bool empty() {
		return m_queue.empty();
	}

	int size() {
		return m_queue.size();
	}

private:
	std::queue<T> m_queue;
	std::mutex m_mutex;
};
