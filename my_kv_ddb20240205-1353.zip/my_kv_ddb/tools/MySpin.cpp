#include "MySpin.h"

#include <chrono>

#if defined(WIN_OS)

#include <Windows.h>

#elif defined(LINUX_OS)

#include <unistd.h>

#endif

bool MySpin::wait_lock(int timeout)
{
	bool expect = false;
	auto start_t = std::chrono::system_clock::now();
	while (!m_spin_lock.compare_exchange_strong(expect, true)) {
		auto current_t = std::chrono::system_clock::now();
		auto deta_t = current_t - start_t;
		auto deta_ms = std::chrono::duration_cast<std::chrono::milliseconds>(deta_t).count();
		if (deta_ms > timeout) break;
		expect = false;

		#if defined(LINUX_OS)
		usleep(1000);
		#elif defined(WIN_OS)
		Sleep(1);
		#endif
	}

	return m_spin_lock.load();
}

void MySpin::unlock()
{
	m_spin_lock.store(false);
}
