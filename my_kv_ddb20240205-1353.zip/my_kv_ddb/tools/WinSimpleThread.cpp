#ifdef WIN_OS

#include "SimpleThread.h"

SimpleThread::SimpleThread(Runnable* runable)
	: m_runnable(runable), m_is_running(false)
{
}

void SimpleThread::Start()
{
    if (m_runnable && !m_is_running) {
        m_is_running = true;
        HANDLE hHandle = CreateThread(NULL, 0, process, (LPVOID)this, 0, NULL);
        if (hHandle != 0) CloseHandle(hHandle);
        else m_is_running = false;
    }
}

DWORD SimpleThread::process(LPVOID lpParam)
{
    SimpleThread* th = (SimpleThread*)lpParam;
    if (th->m_runnable) th->m_runnable->run();
    th->m_is_running = false;
	return 0;
}

#endif
