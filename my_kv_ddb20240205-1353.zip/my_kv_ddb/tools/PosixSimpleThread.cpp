#ifdef LINUX_OS

#include "SimpleThread.h"
#include <pthread.h>
#include <stdio.h>

SimpleThread::SimpleThread(Runnable* runable)
	: m_runnable(runable), m_is_running(false)
{
}

void SimpleThread::Start()
{
    if (m_runnable && !m_is_running) {
        m_is_running = true;
        pthread_t th;
        int ret = pthread_create(&th, nullptr, process, this);
        if(ret != 0){
            perror("SimpleThread create error");
            m_is_running = false;
        }
    }
}

void *SimpleThread::process(void *lpParam)
{
    SimpleThread *th = (SimpleThread*)lpParam;
    if (th->m_runnable) th->m_runnable->run();
    th->m_is_running = false;
	return 0;
}

#endif
