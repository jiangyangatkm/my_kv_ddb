#pragma once
#if defined(WIN_OS)
#include <Windows.h>
#endif

class SimpleThread
{
public:
	class Runnable {
		friend class SimpleThread;
	public:
		virtual ~Runnable() {}
	protected:
		virtual void run() = 0;
	};

public:
	SimpleThread(Runnable* runable);
	void Start();
	bool IsRunning() { return m_is_running; }
private:
	Runnable* m_runnable;
	bool m_is_running;
private:
#if defined(WIN_OS)
	static DWORD process(LPVOID lpParam);
#elif defined(LINUX_OS)
	static void *process(void *param);
#endif
};
