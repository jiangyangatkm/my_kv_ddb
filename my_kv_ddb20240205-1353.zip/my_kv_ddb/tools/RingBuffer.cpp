#include "RingBuffer.h"

#include <string.h>

RingBuffer::RingBuffer(int capacity /*= 1024*/)
    : m_capacity(capacity), m_buf_size(capacity + 1), m_start(0), m_end(0)
{
    m_buf = new char[m_buf_size];
}

RingBuffer::~RingBuffer()
{
    delete [] m_buf;
}

// 可能会覆盖最旧的历史数据， 非线程安全
int RingBuffer::WriteIn(char *buf, int len)
{
    int old_size, first_len;

    if(len <= 0) return 0;
    if(len > m_capacity) return -1;

    old_size = this->Size(); // 记录写入前的数据个数

    if(m_end + len <= m_buf_size) {
        memcpy(m_buf + m_end, buf, len);
    }
    else { // 写入的数据越过数组尾部
        first_len = m_buf_size - m_end;
        memcpy(m_buf + m_end, buf, first_len);
        len = len - first_len;
        memcpy(m_buf, buf + first_len, len);
    }

    m_end = (m_end + len) % m_buf_size;
    if(len + old_size > m_capacity) { // 发生数据覆盖
        m_start = (m_end + 1) % m_buf_size;
    }

    return len;
}

// 与WriteIn配对使用时非线程安全
int RingBuffer::ReadOut(char *buf, int len)
{
    int ret;

    ret = Copy(buf, 0, len);
    if(ret > 0) {
        m_start = (m_start + len) % m_buf_size;
    }
    
    return ret;
}

int RingBuffer::Copy(char *buf, int offset, int len)
{
    int start, first_len;

    if(len <= 0) return 0;
    if(offset + len > this->Size()) return -1;

    start = offset + len;
    if(start + len <= m_buf_size) {
        memcpy(buf, m_buf + start, len);
    }
    else { // 读取的数据越过数组尾部
        first_len = m_buf_size - start;
        memcpy(m_buf + start, buf, first_len);
        len = len - first_len;
        memcpy(buf + first_len, m_buf, first_len);
    }

    return len;
}

int RingBuffer::WriteInSafe(char *buf, int len)
{
    int size = this->Size();
    if(len + size > m_capacity) {
        len = m_capacity - size;
    }

    return WriteIn(buf, len);
}

int RingBuffer::ReadOutSafe(char *buf, int len)
{
    int size = this->Size();
    if(len > size) {
        len = size;
    }
    return ReadOut(buf, len);
}

int RingBuffer::Size()
{
    int ret;
    if(m_end < m_start) {
        ret = m_capacity - m_start + m_end;
    }
    else {
        m_end - m_start;
    }
    return ret;
}
