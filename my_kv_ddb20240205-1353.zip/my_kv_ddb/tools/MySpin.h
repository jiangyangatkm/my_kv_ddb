#pragma once
#include <atomic>

class MySpin
{
public:
	MySpin(): m_spin_lock(false) {}
	~MySpin() { unlock(); }
	bool wait_lock(int timeout = 1000);
	void unlock();
private:
	std::atomic<bool> m_spin_lock;
};
