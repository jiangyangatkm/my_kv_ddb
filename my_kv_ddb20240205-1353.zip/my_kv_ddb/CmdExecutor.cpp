#include "CmdExecutor.h"

#include <string.h>

#include "DdbServer.h"
#include "DdbClient.h"
#include "DdbErrorNo.h"
#include "gadgets.h"

static int info_cmd(DdbClient *client);
static int set_cmd(DdbClient *client);
static int get_cmd(DdbClient *client);
static int flush_all_cmd(DdbClient *client);
static int slaveof_cmd(DdbClient *client);
static int cluster_cmd(DdbClient *client);
static int psync_cmd(DdbClient *client);

static int cluster_addslots_cmd(DdbClient *client);
static int cluster_meet_cmd(DdbClient *client);
static int cluster_info_cmd(DdbClient *client);

static int test_cmd(DdbClient *client);

CmdExecutor::CmdExecutor()
{
    m_cmd_table["set"] = Command(set_cmd, CT_REPLICATION);
    m_cmd_table["get"] = Command(get_cmd, CT_NORMAL);
    m_cmd_table["flushall"] = Command(flush_all_cmd, CT_REPLICATION);
    m_cmd_table["slaveof"] = Command(slaveof_cmd, CT_NORMAL);
    m_cmd_table["cluster"] = Command(cluster_cmd, CT_NORMAL);
    m_cmd_table["info"] = Command(info_cmd, CT_NORMAL);
    m_cmd_table["psync"] = Command(psync_cmd, CT_NORMAL);

    m_cluster_cmd_table["addslots"] = Command(cluster_addslots_cmd, CT_REPLICATION);
    m_cluster_cmd_table["meet"] = Command(cluster_meet_cmd, CT_NORMAL);
    m_cluster_cmd_table["info"] = Command(cluster_info_cmd, CT_NORMAL);

    m_cmd_table["*test"] = Command(test_cmd, CT_NORMAL);
}

CmdExecutor::~CmdExecutor()
{

}

static void do_reply(DdbClient *client, std::string reply) {
    client->DoReply(reply.c_str(), reply.length());
}

int CmdExecutor::Execute(DdbClient *client)
{
    int ret = 0;
    char ** argv = client->GetArgv();
    int argc = client->GetArgc();
    if(argc < 1) return DDBER_FORMAT;
    std::string cmd(argv[0]);
    std::string full_cmd;
    Command command;

    if(m_cmd_table.count(cmd)) {
        if(cmd == "cluster") {
            if(client->GetServer()->GetMode() != MODE_CLUSTER) {
                do_reply(client, "this instance has cluster support disabled\n");
                return DDBER_ILLEGAL;
            }

            cmd = argv[1];
            if(!m_cluster_cmd_table.count(cmd)) {
                do_reply(client, "cluster command can't be found\n");
                return DDBER_NOT_EXIST;
            }
            command = m_cluster_cmd_table[cmd];
        }
        else {
            command = m_cmd_table[cmd];
        }
        
        // 构建命令，积压缓冲和命令传播都用得到
        for(int i=0; i<argc; i++) {
            full_cmd += std::string(" ") + argv[i];
        }
        full_cmd += "\n";

        if(client->GetFlags() & DDB_CLIENT_FLAG_REPLICATION) { // 来自Master的命令
            ret = command.fun(client);
            if(command.type == CT_REPLICATION) {
                client->GetServer()->FeedReplicateBuffer(full_cmd); // 更新积压缓冲区(作为从)
            }
        }
        else { // 来自普通客户端的命令
            if(command.type == CT_REPLICATION) { // 需要进行传播操作的命令
                if (client->GetServer()->GetState() == DdbServer::S_MASTER) {
                    ret = command.fun(client);
                    client->GetServer()->Replicate(full_cmd); // 传播写命令
                    client->GetServer()->FeedReplicateBuffer(full_cmd); // 更新积压缓冲区(作为主)
                }
                else if(client->GetServer()->GetState() == DdbServer::S_SLAVE) {
                    client->GetServer()->ReplicateToMaster(full_cmd); // 写命令需要先传给主服务器
                    do_reply(client, "command has been replicated to master\n");
                    ret = 0;
                }
                else {
                    ret = DDBER_UNKOWN;
                }
            }
            else {
                ret = command.fun(client);
            }
        }
        
        return ret;
    }
    else {
        do_reply(client, "command can't be found\n");
        return DDBER_NOT_EXIST;
    }
}

bool CmdExecutor::IsContainCmd(std::string cmd)
{
    return m_cmd_table.count(cmd) > 0;
}

static int info_cmd(DdbClient *client)
{
    char ** argv = client->GetArgv();
    int argc = client->GetArgc();
    std::string reply;

    if(argc != 1) {
        do_reply(client, "arguments number error:arguments number of info command is 0!\n");
        return DDBER_ARG_NUM;
    }

    DdbInfo info;
    DdbServer * server = client->GetServer();
    server->GetInfo(&info);

    for(std::pair<std::string, std::string> pair : info) {
        reply += pair.first + ": " + pair.second + "\n";
    }

    do_reply(client, reply);

    return 0;
}

static int set_cmd(DdbClient *client)
{
    char ** argv = client->GetArgv();
    int argc = client->GetArgc();

    if(argc != 3) {
        do_reply(client, "arguments number error:arguments number of set command is 2!\n");
        return DDBER_ARG_NUM;
    }

    DdbServer * server = client->GetServer();
    return server->Set(client);
    // unsigned int mode = server->GetMode();
    // server->Set(argv[1], argv[2]);
    // do_reply(client, "ok\n");

    // return 0;
}

static int get_cmd(DdbClient *client) {
    char ** argv = client->GetArgv();
    int argc = client->GetArgc();

    if(argc != 2) {
        do_reply(client, "arguments number error:arguments number of get command is 1!\n");
        return DDBER_ARG_NUM;
    }

    DdbServer * server = client->GetServer();
    return server->Get(client);
}

static int flush_all_cmd(DdbClient *client)
{
    client->GetServer()->ClearAll();
    do_reply(client, "ok\n");
    return 0;
}

static int slaveof_cmd(DdbClient *client) {
    char ** argv = client->GetArgv();
    int argc = client->GetArgc();

    if(argc != 3) {
        do_reply(client, "arguments number error: arguments number of slaveof command is 2!\n");
        return DDBER_ARG_NUM;
    }

    if((strcmp(argv[1], "no") == 0) &&
       (strcmp(argv[2], "one") == 0)) {
        return client->GetServer()->SlaveOfNoOne(client);
    }
    else {
        return client->GetServer()->SlaveOf(client);
    }
}

static int cluster_cmd(DdbClient *client) {
    return 0;
}

static int psync_cmd(DdbClient *client) {
    char ** argv = client->GetArgv();
    int argc = client->GetArgc();

    if(argc != 3) {
        do_reply(client, "arguments number error: arguments number of psync command is 2!\n");
        return DDBER_ARG_NUM;
    }

    if((strcmp(argv[1], "?") == 0) && 
        (strcmp(argv[2], "-1") == 0)) {
        return client->GetServer()->FullSync(client);
    }
    else {
        return client->GetServer()->PartSync(client);
    }
}

static int cluster_addslots_cmd(DdbClient *client)
{
    char ** argv = client->GetArgv();
    int argc = client->GetArgc();
    std::string arg, reply;
    std::vector<std::string> sub_args;
    bool is_ok;
    int slot, count, i;
    DdbServer *server;
    IntPairList slots;

    server = client->GetServer();
    for(i=2; i<argc; i++) {
        arg = argv[i];
        sub_args = my_strsplit(arg, '~');
        if(sub_args.size() == 1) {
            slot = my_strtoi(sub_args[0].c_str(), &is_ok);
            if(!is_ok) goto Error;

            slots.push_back(IntPair(slot, 1));
        }
        else if(sub_args.size() == 2) {
            slot = my_strtoi(sub_args[0].c_str(), &is_ok);
            if(!is_ok) goto Error;
            count = my_strtoi(sub_args[1].c_str(), &is_ok) - slot + 1;
            if(!is_ok || count <= 0) goto Error;

            slots.push_back(IntPair(slot, count));
        }
        else {
            goto Error;
        }
    }

    server->AddSlots(slots);
    do_reply(client, "ok\n");
    return 0;
Error:
    reply = "argument: " + std::to_string(i - 2) + "parse error\n";
    do_reply(client, reply);
    return DDBER_ILLEGAL;
}

static int cluster_meet_cmd(DdbClient *client) {
    char ** argv = client->GetArgv();
    int argc = client->GetArgc();
    int ret;

    if(argc != 4) {
        do_reply(client, "arguments number error: arguments number of cluster meet command is 2!\n");
        return DDBER_ARG_NUM;
    }

    int port = atoi(argv[3]);
    if(port <=0 || port > 65535) {
        do_reply(client, "port format error\n");
        return DDBER_FORMAT;
    }

    ret = client->GetServer()->Meet(argv[2], port);
    if(ret == 0) {
        do_reply(client, "meet message is sent\n");
    }
    else if(ret == DDBER_ANET) {
        do_reply(client, "address error\n");
    }
    else if(ret == DDBER_EXISTED) {
        do_reply(client, "this node has meet\n");
    }
    else if(ret < 0) {
        do_reply(client, "unkown error\n");
    }

    return ret;
}

static int cluster_info_cmd(DdbClient *client) {
    char ** argv = client->GetArgv();
    int argc = client->GetArgc();
    int flags;
    DdbInfo info;
    std::string reply;

    if(argc == 2) {
        flags = DDB_INFO_FLAG_BASIC;
    }
    else if(argc == 3) {
        if(strcmp(argv[2], "all") == 0) {
            flags = DDB_INFO_FLAG_ALL;
        }
        else if(strcmp(argv[2], "node") == 0) {
            flags = DDB_INFO_FLAG_NODE;
        }
        else if(strcmp(argv[2], "slot") == 0) {
            flags = DDB_INFO_FLAG_SLOT;
        }
        else {
            do_reply(client, "argument 1 error: unkown argument!\n");
            return DDBER_PARSE;
        }
    }
    else {
        do_reply(client, 
            "arguments number error: arguments number of cluster info command is 0 or 1!\n");
        return DDBER_ARG_NUM;
    }

    client->GetServer()->GetClusterInfo(&info, flags);

    for(std::pair<std::string, std::string> pair : info) {
        reply += pair.first + ": " + pair.second + "\n";
    }

    do_reply(client, reply);

    return 0;
}

static int test_cmd(DdbClient *client) {
    return client->GetServer()->Test(client);
}
