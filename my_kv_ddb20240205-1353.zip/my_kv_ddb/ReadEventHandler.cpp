#include "ReadEventHandler.h"
#include "MyResource.h"
#include <unistd.h>

ReadEventHandler::ReadEventHandler()
{

}

ReadEventHandler::~ReadEventHandler()
{

}

void ReadEventHandler::on_event(DdbEvent *e)
{
    if(e->id == KV_DDB_EVENT_SOCKET_READ) {
        // 实现一个echo服务器
        SockReadData * sockdata = (SockReadData *)e->data;
        SocketBuffer *buffer = (SocketBuffer *)sockdata->data;
        int len = buffer->Capacity();
        char *sendback = new char[len];
        len = buffer->ReadOut(sendback, len);
        write(sockdata->sfd, sendback, len);
        delete[] sendback;
    }
    else if(e->id == KV_DDB_EVENT_SOCKET_READ_ERROR) {
        SockErrorData * sockdata = (SockErrorData*)e->data;
        SocketBuffer *buffer = (SocketBuffer *)sockdata->data;
        close(sockdata->sfd);
        MyResource::GetSocketBufferPool()->ReturnBuffer(buffer);
    }
}
