#ifndef SOCKETAPI_H
#define SOCKETAPI_H

#pragma once

#define SOCKET_EER          -1
#define SOCKET_OK           0

class SocketApi
{
public:
    SocketApi() = delete;
    ~SocketApi() = delete;
public:
    // 当ip和local_ip保存了多组地址时，如果有一组成功，就返回结果
    static int connect(const char *ip, unsigned short port, const char *local_ip);
    static int create_server(const char *ip, unsigned short port);
    static int listen(int s, int n);
    static int send(int s, const char *buf, int len);
    static int recv(int s, char *buf, int len);
    static int send_with_timeout(int s, const char *buf, int len, int ms);
    static int recv_with_timeout(int s, char *buf, int len, int ms);
    static void close(int s);
    static int get_bytes_num_in_sbuffer(int s);
    static int get_bytes_num_in_rbuffer(int s);
private:

};

#endif