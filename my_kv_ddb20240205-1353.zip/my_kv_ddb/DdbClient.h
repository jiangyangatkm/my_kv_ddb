#ifndef DDBCLIENT_H
#define DDBCLIENT_H

#pragma once

#include "SocketBufferPool.h"

#define MAX_CMD_LEN     1024
#define MAX_ARG_NUM     32

#define DDB_CLIENT_FLAG_REPLICATION             1

class DdbServer;
class DdbClient;

class ICmdProcessor 
{
public:
    virtual int Execute(DdbClient *client) = 0;
};

class DdbClient
{
public:
    DdbClient(DdbServer *server, char * server_name, int sfd, SocketBuffer *buffer);
    ~DdbClient();
public:
    void DoRead();
    virtual void DoReply(const char *reply, int len);

    int GetSocketFd() { return m_sfd; }
    void SetReplyEnable(bool enable);
    DdbServer *GetServer() { return m_server; }
    char **GetArgv() { return m_argv; }
    int GetArgc() { return m_argc; }

    int GetFlags() { return m_flags; }
    void SetFlags(int flags) { m_flags = flags; }

    void SetPreProcessor(ICmdProcessor *p) { m_preprocessor = p; }
    void SetPostProcessor(ICmdProcessor *p) { m_postprocessor = p; }

    static bool parse_cmd(char *cmd, int cmd_len, char *argv[], int *argc);
protected:
    int try_read_cmd();
    void execute_processor(ICmdProcessor *processor);
protected:
    DdbServer *m_server;
    char * m_server_name;

    int m_sfd;
    SocketBuffer *m_in_buffer;

    char m_cmd[MAX_CMD_LEN];
    char * m_argv[MAX_ARG_NUM];
    int m_argc;
    int m_ret;

    bool m_is_valid;
    bool m_is_reply;
    int m_flags;

    ICmdProcessor *m_preprocessor;
    ICmdProcessor *m_postprocessor;
};

#endif