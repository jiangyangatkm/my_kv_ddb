#include "EpollReader.h"

#include <sys/epoll.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <assert.h>
#include <string>

#include "EventData.h"
#include "EventHelper.h"
#include "MyResource.h"
#include "os_api.h"
#include "gadgets.h"

#define EPOLL_FD_MAX_NUM    1024*8
#define MAX_EVENTS          (EPOLL_FD_MAX_NUM + 1)
#define MAX_EPOLL_READER    8

EpollReader::EpollReader(char * server_name, EventLoop *eloop, int listen_fd /* = -1*/)
    : m_epfd(-1), m_listen_fd(-1), m_is_exit(false), m_thread(this), 
    m_server_name(server_name), m_eloop(eloop)
{
    if(listen_fd >= 0) { // 传入的监听socket描述符有效，本EpollReader为主Reader
        m_listen_fd = listen_fd;
        // 将自身加入EpollReader列表中，以充分利用主Read的线程
        m_reader_list.push_front(this); 
    }

    // 创建epoll
    m_epfd = epoll_create1(0);
    if (m_epfd == -1) {
        perror("epoll_create1");
    }
}

EpollReader::~EpollReader()
{
    m_is_exit = true;
    // 关闭epoll描述符
    close(m_epfd);
    // 释放EpollReader
    for(EpollReader * reader: m_reader_list) {
        if(reader != this) delete reader;
    }
}

bool EpollReader::IsFull()
{
    if(m_socket_set.size() >= EPOLL_FD_MAX_NUM) {
        return true;
    }
    else {
        return false;
    }
}

void EpollReader::AddFd(int fd)
{
    if(!IsFull()) {
        SocketBuffer *buffer = MyResource::GetSocketBufferPool()->GetBuffer();
        insert_buffer(fd, buffer);
        add_event(m_epfd, fd, EPOLLIN);
    }
}

void EpollReader::AddFd(int fd, SocketBuffer *buffer)
{
    assert(buffer != nullptr);

    if(!IsFull()) {
        insert_buffer(fd, buffer);
        add_event(m_epfd, fd, EPOLLIN);   
    }
}

void EpollReader::Start()
{
    if(m_epfd == -1) return;
    
    if(!m_thread.IsRunning()) {
        m_thread.Start();
    }
}

int EpollReader::GetConnectNum()
{
    int num = 0;
    // 如果有，统计子EpollReader的连接
    for(EpollReader *reader: m_reader_list){
        if(reader != this) num += reader->GetConnectNum();
    }
    // 统计本EpollReader的连接
    num += m_socket_set.size();

    return num;
}

bool EpollReader::add_event(int epfd, int fd, uint32_t events)
{
    struct epoll_event ev;
    ev.events = events;
    ev.data.fd = fd;
    if (epoll_ctl(epfd, EPOLL_CTL_ADD, fd, &ev) == -1) {
        perror("epoll_ctl: EPOLL_CTL_ADD");
        return false;
    }
    return true;
}

void EpollReader::remove_event(int epfd, int fd)
{
    if (epoll_ctl(epfd, EPOLL_CTL_DEL, fd, NULL) == -1) {
        std::string info = "EPOLL_CTL_DEL:" + 
            std::string(m_server_name) + ":" + std::to_string(fd);
        perror(info.c_str());
    }
}

SocketBuffer *EpollReader::get_buffer(int sfd)
{
    m_socket_set_lock.lock();
    SocketBuffer * buffer = m_socket_set.at(sfd);
    m_socket_set_lock.unlock();
    return buffer;
}

void EpollReader::insert_buffer(int sfd, SocketBuffer *buffer)
{
    m_socket_set_lock.lock();
    m_socket_set[sfd] = buffer;
    m_socket_set_lock.unlock();
}

void EpollReader::erase_buffer(int sfd)
{
    m_socket_set_lock.lock();
    m_socket_set.erase(sfd);
    m_socket_set_lock.unlock();
}

void EpollReader::run()
{
    // 异常处理，以确保EpollReader析构时线程不会产异常
    try {
        do_epoll();
    }
    catch(...) {

    }
}

void EpollReader::do_epoll()
{
    int nfds, fd, i, n;
    struct epoll_event ev, events[MAX_EVENTS];
    struct sockaddr client_addr;
    socklen_t addr_size;
    EventLoop * eloop;
    bool is_something_to_do;

    // 如果m_listen_fd有效, 添加listener的事件
    if(m_listen_fd >=0 && !add_event(m_epfd, m_listen_fd, EPOLLIN)){
        perror("cannot add event to m_listen_fd");
        close(m_epfd);
        return;
    }
    // 获得事件循环对象
    eloop = m_eloop;

    // long long d_time;
    // auto test_s = [&](std::string pos){
    //     long long w_time = mstime() - d_time;
    //     if(w_time > 5000) {
    //         printf("%s:%s:%s wait time(%lld) to long\n", pos.c_str(),
    //             get_str_time().c_str(), m_server_name, w_time);
    //     }  
    // };

    // todo 用管道实现优雅退出
    while(!m_is_exit) {
        // 等待事件到来
        nfds = epoll_wait(m_epfd, events, MAX_EVENTS, 1000);
        if(m_is_exit) break;
        if(nfds == 0) continue;
        
        if (nfds == -1) {
            perror("epoll_wait");
            // break;
            continue;
        }

        // 检查是否有事件需要处理
        // 因为SocketBuffer满时，无法读入数据，
        // 防止在这种情况下，做反复检查的无用功
        is_something_to_do = false;
        for(i = 0; i < nfds; i++) {
            int sfd = events[i].data.fd;
            if (sfd == m_listen_fd){
                is_something_to_do = true;
                break;
            }
            else {
                // 获得套接字对应的缓存对象
                SocketBuffer * buffer = get_buffer(sfd);
                if(!buffer->IsFull()) {
                    is_something_to_do = true;
                    break;
                }
            }
        }
        // 如果无事可做，先休息一会
        if(is_something_to_do == false) {
            //printf("wait buffer read out\n");
            usleep(5000);
            continue;
        }

        // 遍历处理到来的事件
        for (i = 0; i < nfds; i++) {
            if (events[i].data.fd == m_listen_fd) { // 处理连接事件，主reader的特权
                int conn_fd = accept(m_listen_fd, &client_addr, &addr_size);
                if (conn_fd == -1) {
                    perror("accept");
                    continue;
                }

                bool is_all_full = true;
                for(EpollReader * reader: m_reader_list) {
                    if(!reader->IsFull()){
                        reader->AddFd(conn_fd);                    
                        is_all_full = false;
                        break;
                    }
                }
                if(is_all_full == true) {
                    if(m_reader_list.size() >= MAX_EPOLL_READER){
                        // printf("too many client\n");
                        close(conn_fd); // 拒绝连接
                        continue;
                    }

                    EpollReader * reader = new EpollReader(m_server_name, m_eloop);
                    reader->Start();
                    reader->AddFd(conn_fd);
                    m_reader_list.push_front(reader);
                }
                // 获得套接字对应的缓存对象
                SocketBuffer * buffer = get_buffer(conn_fd);
                // 发送accept事件             
                EventHelper::PushAcceptEvent(
                    eloop, conn_fd, m_server_name, &client_addr, addr_size, buffer);
            }
            else { // 处理读事件
                int sfd = events[i].data.fd;
                // 获得套接字对应的缓存对象
                SocketBuffer * buffer = get_buffer(sfd);
                // 缓冲区满，继续
                if(buffer->IsFull()) {
                    continue; // 不继续执行，以确保正常情况下，写入缓冲区数据个数大于0
                }
                // 将套接字中的数据读入缓存对象
                // d_time = mstime();
                int ret = buffer->WriteIn(sfd);
                // test_s("writein");
                if(ret > 0){
                    // 发送读事件
                    EventHelper::PushReadEvent(eloop, sfd, m_server_name, buffer);
                }
                else { // 读取异常
                    // 清除sfd的事件监控
                    remove_event(m_epfd, sfd);
                    // close(sfd); todo
                    // 清除m_socket_set中的sfd项
                    erase_buffer(sfd);
                    // 发送读错误事件，为了防止使用中的资源释放，资源释放工作交给使用者处理
                    EventHelper::PushReadErrorEvent(eloop, sfd, m_server_name, buffer, ret);
                    // printf("read error: ret = %d\n", ret);             
                }
            }
        }
    }
}
