#ifndef LISTENER_H
#define LISTENER_H

#pragma once

class Listener
{
public:
    Listener();
    ~Listener();

    int accept();
private:
    int _fd;
};

#endif