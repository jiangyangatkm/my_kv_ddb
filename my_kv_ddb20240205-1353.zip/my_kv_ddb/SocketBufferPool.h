#pragma once

#include <vector>
#include <unordered_set>
#include <mutex>

class SocketBuffer {
	public:
		static const int DEFAULT_BUF_SIZE = 1024*8;
	public:
		SocketBuffer(int capacity = DEFAULT_BUF_SIZE);
		int ReadOut(char * out_buf, int len);
		int WriteIn(int s);
		void Reset();
		int Capacity();
		bool IsFull();
		int Size();

		int Start(){ return m_start; }
		int End(){ return m_end; }
		char At(int index) { return m_buf[index % Capacity()]; }
	private:
		std::vector<char> m_buf;
		int m_start;
		int m_end;
};
// todo 解决重复Return问题 *
class SocketBufferPool
{
public:
	SocketBufferPool() = default;
	~SocketBufferPool();
	SocketBuffer* GetBuffer();
	void ReturnBuffer(SocketBuffer* buf);
private:
	SocketBuffer *get_unused_buf();
	void return_unused_buf(SocketBuffer* buf);
private:
	std::vector<SocketBuffer*> m_pool;
	std::mutex m_pool_lock;
	std::unordered_set<SocketBuffer*> m_unused_buf;
	std::mutex m_unused_lock;
};
