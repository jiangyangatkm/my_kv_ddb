#include "EventLoop.h"

#include <unistd.h>
#include "os_api.h"

EventLoop::EventLoop()
    : m_exit(false), m_is_front_change(false)
{

}

EventLoop::~EventLoop()
{
    m_exit = false;
}

bool EventLoop::RegisterEventHanler(unsigned int event_id, EventHandler *handler)
{
    if(handler == nullptr) return false;
    if(m_handler_map.count(event_id)) return false;

    m_handler_map[event_id] = handler;
    return true;
}

void EventLoop::UnregisterEventHanler(unsigned int event_id)
{
    m_handler_map.erase(event_id);
}

void EventLoop::PushEvent(DdbEvent *event)
{
    m_event_queue.push(event);
    
    m_loop_cv.notify_all(); // 如果event_loop在休眠，唤醒它
}

void EventLoop::PushTimeEvent(DdbTimeEvent *event)
{
    m_time_event_lock.lock();
    m_time_event_queue.emplace(event);
    m_time_event_lock.unlock();

    // 如果从没有事件到有事件，唤醒eloop
    if(front_time_event() == event) {
        m_is_front_change = true;
        m_loop_cv.notify_all();
    }
}

void EventLoop::Run()
{
    auto pred = [&](){
        return has_event() || has_time_event_to_do() || m_is_front_change;
    };

    while(!m_exit) {
        int wait_time = 100000;
        if(front_time_event()) wait_time = front_time_event()->timeout - mstime();
        if(wait_time > 0) {
            std::chrono::duration<int, std::milli> timeout(wait_time + 1);
            std::unique_lock<std::mutex> lock(m_loop_mutex);
            m_loop_cv.wait_for(lock, timeout, pred);
            // 处理时间事件队列队首改变
            if(m_is_front_change) {
                // 复位队首改变条件
                m_is_front_change = false;
                // 如果没有事件需要处理，则继续循环，以重新设置等待时间
                if(!has_event() && !has_time_event_to_do()) continue;
            }
        }

        while(has_event() || has_time_event_to_do()) {
            // 处理时间事件
            if(has_time_event_to_do()) {
                DdbTimeEvent *t_event = front_time_event();
                do_event(t_event);
                remove_time_event(t_event);
            }
            // 处理事件
            if(has_event()) {
                DdbEvent *event = m_event_queue.pop();
                // 检查退出事件
                if(event->id == KV_DDB_EVENT_QUIT_LOOP){
                    delete event;
                    break;
                }
                do_event(event);
            }
        }
    }
}

void EventLoop::do_event(DdbEvent *event)
{
    if(m_handler_map.count(event->id)){
        EventHandler *handler = m_handler_map[event->id];
        if(handler != nullptr) handler->on_event(event);
    }
    // 释放事件数据
    if(event->data != nullptr) delete event->data;
    delete event;
}

DdbTimeEvent *EventLoop::front_time_event()
{
    DdbTimeEvent *e;
    m_time_event_lock.lock();
    e = *m_time_event_queue.begin();
    m_time_event_lock.unlock();
    return e;
}

void EventLoop::remove_time_event(DdbTimeEvent *e)
{
    m_time_event_lock.lock();
    m_time_event_queue.erase(e);
    m_time_event_lock.unlock();
}

bool EventLoop::has_time_event_to_do()
{
    if(!front_time_event()) return false;

    return front_time_event()->timeout <= mstime();
}

bool EventLoop::has_event()
{
    return !m_event_queue.empty();
}
