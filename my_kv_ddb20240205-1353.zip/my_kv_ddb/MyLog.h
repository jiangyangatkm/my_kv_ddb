#ifndef MYLOG_H
#define MYLOG_H

#pragma once

#include <string>
#include <stdarg.h>
#include <stdio.h>

#define LOG_MAX_LEN 1024

class MyLog
{
public:
    MyLog(const char *file_name, int max_log_count = INT32_MAX);
    ~MyLog();
public:
    void Log(const char *fmt, __gnuc_va_list arg);
    void Log(const char *fmt, ...);

    void Clear();
private:
    std::string m_file_name;
    int m_max_count;
    int m_log_count;
};

#endif