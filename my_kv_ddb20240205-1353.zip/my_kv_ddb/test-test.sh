cd build
./my_kv_ddb 192.168.227.128 8101 &
./my_kv_ddb 192.168.227.128 8102 &
cd ..

sleep 2

read -p "press q to quit: " input
while [ "$input" != "q" ]
do
    read -p "press q to quit: " input
done

killall my_kv_ddb