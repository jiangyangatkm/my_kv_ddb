#include "os_api.h"

#include <sys/time.h>
#include <stdio.h>
#include <time.h>

// todo存在0点溢出的问题
long long ustime() {
    struct timeval tv;
    long long ust;

    gettimeofday(&tv, nullptr);
    ust = ((long long)tv.tv_sec)*1000000;
    ust += tv.tv_usec;
    return ust;
}

long long mstime()
{
    return ustime() / 1000;
}

static void _get_time_str(char *str_time, int len, const char *fmt)
{
    int off;
    struct timeval tv;
    struct timezone tz;
    int role_char;

    gettimeofday(&tv, &tz);
    struct tm tm;
    localtime_r(&tv.tv_sec, &tm);
    off = strftime(str_time, len, fmt, &tm);
    snprintf(str_time+off, len-off, ".%03d", (int)tv.tv_usec/1000);
}

void get_mstime_str(char *str_time, int len)
{
    _get_time_str(str_time, len, "%d %b %Y %H:%M:%S");
}

void get_mstime_str_2(char *str_time, int len)
{
    _get_time_str(str_time, len, "%d-%b-%Y-%H-%M-%S");
}
