#ifndef     DDBERRORNO_H
#define     DDBERRORNO_H

#define DDBER_NOT_EXIST         -1
#define DDBER_FORMAT            -2
#define DDBER_ARG_NUM           -3
#define DDBER_ADDRESS           -4
#define DDBER_ANET              -5
#define DDBER_EXISTED           -6
#define DDBER_UNKOWN            -7
#define DDBER_TIMEOUT           -8
#define DDBER_ILLEGAL           -9
#define DDBER_PARSE             -10

#endif /*DDBERRORNO_H*/