#ifndef DDBEVENTTIMER_H
#define DDBEVENTTIMER_H

#pragma once

#include <vector>

#include "EventBase.h"
#include "EventLoop.h"

class DdbTimerManager;

class DdbTimerBase {
    friend DdbTimerManager;
public:
    DdbTimerBase(long long interval, bool is_loop)
        : m_is_loop(is_loop), m_interval(interval),
          m_is_started(false), m_id(-1), m_mng(nullptr) {}
    virtual ~DdbTimerBase(){}
    virtual void on_timeout(){};
protected:
    void SetIsLoop(bool bl) { m_is_loop = bl; }
    void SetInterval(long long interval) { m_interval = interval; }

    void Start();
protected:
    bool m_is_loop;
    bool m_is_started;
    long long m_interval;

    int m_id;
    DdbTimerManager *m_mng;
};

class DdbTimerManager: public EventHandler
{
public:
    DdbTimerManager(EventLoop *eloop);
public:
    void on_event(DdbEvent *e);

    int AddTimer(DdbTimerBase *timer, bool auto_start = true);
    void StartTimer(int timer_id);
    void RemoveTimer(int timer_id);
private:
    void push_event(int timer_id, DdbTimerBase *timer);
private:
    int m_timer_count;
    std::vector<DdbTimerBase*> m_timers;

    EventLoop *m_eloop;
};

#endif