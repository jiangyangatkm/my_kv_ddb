#include "TcpServer.h"

#include <netinet/in.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>

#include "SocketApi.h"

TcpServer::TcpServer(std::string ip, unsigned short port, EventLoop *eloop)
    : m_ip(ip), m_port(port), m_listener_fd(-1), m_reader(nullptr), m_is_running(false)
{
    // 初始化名称
    memset(m_server_name, 0, sizeof(m_server_name));
    make_server_name(m_server_name, m_ip, m_port);
    // 创建并绑定socket
    m_listener_fd = SocketApi::create_server(m_ip.c_str(), m_port);
    if(m_listener_fd == SOCKET_EER) {
        m_listener_fd = -1;
        return;
    }
    m_reader = new EpollReader(m_server_name, eloop, m_listener_fd);
}

TcpServer::~TcpServer()
{
    if(m_reader != nullptr) delete m_reader;
    if(m_listener_fd != -1) close(m_listener_fd);
}

int TcpServer::Start()
{
    if(m_listener_fd == -1) return -1;

    if(IsRuning()) return 0; // 根据m_reader的值判断是否在运行

    // 开始侦听
    if(SocketApi::listen(m_listener_fd, 100) != 0) return -2;
    // 启动Epoll线程
    m_reader->Start();

    m_is_running = true;
    
    return 1;
}

const char *TcpServer::GetIp()
{
    return m_ip.c_str();
}

unsigned short TcpServer::GetPort()
{
    return m_port;
}

bool TcpServer::IsRuning()
{
    return m_is_running;
}

int TcpServer::GetConnectNum()
{
    int num = 0;
    if(m_reader != nullptr) {
        num = m_reader->GetConnectNum();
    }
    return num;
}

const char *TcpServer::GetName()
{
    return m_server_name;
}

void TcpServer::make_server_name(char *out_name, std::string ip, unsigned short port)
{
    sprintf(out_name, "%s:%u", ip.c_str(), port);
}
