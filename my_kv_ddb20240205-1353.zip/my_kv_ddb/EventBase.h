#ifndef EVENTBASE_H
#define EVENTBASE_H

#pragma once

class EventDataBase {
public:
    virtual ~EventDataBase(){}
};

class DdbEvent {
public:
    virtual ~DdbEvent(){}
    
    unsigned int id;
    EventDataBase *data;
};

class DdbTimeEvent: public DdbEvent {
public:
    long long timeout;
};

class EventHandler 
{
public:
    virtual void on_event(DdbEvent *e) = 0;
    virtual ~EventHandler() {}
};

#endif