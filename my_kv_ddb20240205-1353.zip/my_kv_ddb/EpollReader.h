#ifndef EPOLLREADER_H
#define EPOLLREADER_H

#pragma once

#include <unordered_map>
#include <list>
#include <mutex>
#include <sys/socket.h>
#include "tools/MySpin.h"
#include "tools/SimpleThread.h"
#include "SocketBufferPool.h"
#include "EventLoop.h"

class EpollReader: public SimpleThread::Runnable
{
public:
    EpollReader(char * server_name, EventLoop *eloop, int listen_fd = -1);
    ~EpollReader();
public:
    bool IsFull();
    void AddFd(int fd);
    void AddFd(int fd, SocketBuffer *buffer);
    void Start();
    int GetConnectNum();
private:
    bool add_event(int epfd, int fd, uint32_t events);
    void remove_event(int epfd, int fd);
    SocketBuffer *get_buffer(int sfd);
    void insert_buffer(int sfd, SocketBuffer *buffer);
    void erase_buffer(int sfd);

    void run();
    void do_epoll();
private:
    int m_epfd;
    int m_listen_fd;
    std::unordered_map<int, SocketBuffer*> m_socket_set;
    std::mutex m_socket_set_lock; // STL数据不支持线程安全，需要额外加锁
    std::list<EpollReader*> m_reader_list;

    bool m_is_exit;
    SimpleThread m_thread;

    char * m_server_name;

    EventLoop *m_eloop;
};

#endif
