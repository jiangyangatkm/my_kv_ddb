#ifndef EVENTLOOP_H
#define EVENTLOOP_H

#pragma once

#include <unordered_map>
#include <set>
#include <mutex>
#include <condition_variable>
#include "tools/concurrent_queue.h"
#include "EventBase.h"

#define KV_DDB_EVENT_QUIT_LOOP      1<<31

struct TimeEventCompare {
    bool operator()(const DdbTimeEvent *l, const DdbTimeEvent *r) const
    {
        if(l->timeout < r->timeout) {
            return true;
        }
        else if(l->timeout == r->timeout) {
            return l < r;
        }
        else {
            return false;
        }
    }
};

class EventLoop
{
public:
    EventLoop();
    ~EventLoop();
public:
    bool RegisterEventHanler(unsigned int event_id, EventHandler * handler);
    void UnregisterEventHanler(unsigned int event_id);
    void PushEvent(DdbEvent *event);
    void PushTimeEvent(DdbTimeEvent *event);
    void Run();
private:
    void do_event(DdbEvent *event);

    DdbTimeEvent * front_time_event();
    void remove_time_event(DdbTimeEvent *e);
    bool has_time_event_to_do();
    bool has_event();
private:
    std::unordered_map<unsigned int, EventHandler *> m_handler_map;
    concurrent_queue<DdbEvent *> m_event_queue;
    std::set<DdbTimeEvent *, TimeEventCompare> m_time_event_queue;
    std::mutex m_time_event_lock; // 保证m_time_event_queue的并发安全
    bool m_is_front_change; // 当队首改变时，用于退出条件变量

    // 用于同步事件输入和事件循环的互斥对象和条件变量
    std::mutex m_loop_mutex;
    std::condition_variable m_loop_cv;

    bool m_exit;
};

#endif