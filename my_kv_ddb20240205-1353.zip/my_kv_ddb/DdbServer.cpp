#include "DdbServer.h"

#include <unistd.h>
#include <string.h>
#include <assert.h>
#include <stdarg.h>

#include "EventLoop.h"
#include "EventData.h"
#include "EventHelper.h"
#include "MyResource.h"
#include "DdbErrorNo.h"
#include "SocketApi.h"
#include "gadgets.h"
#include "os_api.h"

static void release_socket(int fd, SocketBuffer *buffer);

DdbServer::DdbServer()
    : m_fake_client(this), m_log(nullptr), m_mode(MODE_NORMAL), 
    m_is_initialized(false), m_normal_tcpserver(nullptr), 
    m_cluster_tcpserver(nullptr), m_clients_reader(&m_eloop), 
    m_dbs(nullptr), m_dbs_size(0), m_state(S_MASTER), m_repl_offset(0), 
    m_repl_buf(nullptr)
{
    m_timer_handler = new TimerHandler(this);
    m_fq_alarm = new FailoverRequestAlarm(this);
    m_server = new Server(this);
    m_cluster = new Cluster(this);
    m_master = new Master(this);
    m_ascliets = new AsClients(this);
}

DdbServer::~DdbServer()
{
    if(m_log != nullptr) delete m_log;
    if(m_normal_tcpserver != nullptr) delete m_normal_tcpserver;
    if(m_cluster_tcpserver != nullptr) delete m_cluster_tcpserver;
    delete m_timer_handler;
    delete m_fq_alarm;
    delete m_server;
    delete m_cluster;
    delete m_master;
    delete m_ascliets;

    release_dbs();
}

int DdbServer::Initialize(DdbServerConfig * config /*= nullptr*/)
{
    DdbServerConfig config_bak;

    if(m_is_initialized) return 0;

    if(config == nullptr) {
        config = &config_bak;
        if(!load_config(config)) return -1;
    }

    if(config->log_enable) {
        char str_time[80];
        get_mstime_str_2(str_time, sizeof(str_time));
        std::string log_name = std::string("log/") +
            config->ip + "-" + std::to_string(config->main_port);
        
        m_log = new MyLog(log_name.c_str());
        m_log->Clear();
    }
    
    m_normal_tcpserver = new TcpServer(config->ip, config->main_port, &m_eloop);
    m_cluster_tcpserver = new TcpServer(config->ip, config->cluster_port, &m_eloop);
    m_handler_map[m_normal_tcpserver->GetName()] = m_server;
    m_handler_map[m_cluster_tcpserver->GetName()] = m_cluster;
    m_handler_map[m_clients_reader.GetName()] = m_ascliets;

    m_eloop.RegisterEventHanler(KV_DDB_EVENT_SOCKET_ACCEPTED, this);
    m_eloop.RegisterEventHanler(KV_DDB_EVENT_SOCKET_READ, this);
    m_eloop.RegisterEventHanler(KV_DDB_EVENT_SOCKET_READ_ERROR, this);
    m_eloop.RegisterEventHanler(KV_DDB_EVENT_TIMER_TIMEOUT, this);
    m_eloop.RegisterEventHanler(KV_DDB_EVENT_DELAY_TIMEOUT, this);

    m_mode = config->mode;

    if(config->mode == MODE_CLUSTER) { // cluster模式
        // cluster模式只有在槽完成分配时才能创建具体的数据库
        create_cluster_dbs();
    }
    else {
        create_normal_dbs();
    }

    m_repl_buf = new RingBuffer(config->repl_buf_size);

    m_is_initialized = true;
    return 1;
}

void DdbServer::Log(const char *fmt, ...)
{
    if(m_log == nullptr) return;

    va_list ap;
    va_start(ap, fmt);
    m_log->Log(fmt, ap);
    va_end(ap);
}

void DdbServer::LogNode(ClusterNode *node, std::string info)
{
    assert(node != nullptr);
    Log("port:%d node info:%s info:%s",
     node->GetPort(), node->GetInfo().c_str(), info.c_str());
}

void DdbServer::LogNode2(ClusterNode *node, std::string info)
{
    assert(node != nullptr);
    if(m_cluster->d_node_names.count(node->GetName())) {
        Log("fd:%d port:%d info:%s", node->GetFd(),
            node->GetPort(), info.c_str());
    }
}

void DdbServer::Run()
{
    if(m_is_initialized){
        m_normal_tcpserver->Start();
        m_cluster_tcpserver->Start();
        // Log("DdbServer start");
        m_eloop.Run();
    }
}

void DdbServer::ClearAll()
{
    assert(m_dbs != nullptr);
    if(IsMutiSlots()) {
        for(int i=0; i<m_dbs_size; i++) {
            if(m_dbs[i] != nullptr) m_dbs[i]->clear();
        }
    }
    else {
        clear(0);
    }
}

void DdbServer::Set(std::string key, std::string value)
{
    int slot = parse_slot(key);
    if(slot >= 0) {
        set(slot, key, value);
    }
}

std::string DdbServer::Get(std::string key)
{
    int slot = parse_slot(key);
    if(slot >= 0) {
        return get(slot, key);
    }
    else {
        return "";
    }
}

void DdbServer::Erase(std::string key)
{
    int slot = parse_slot(key);
    if(slot >= 0) {
        erase(slot, key);
    }
}

bool DdbServer::ContainKey(std::string key)
{
    int slot = parse_slot(key);
    if(slot >= 0) {
        return contain_key(slot, key);
    }
    else {
        return false;
    }
}

int DdbServer::Size()
{
    if(IsMutiSlots()) {
        int sum = 0;
        for(int slot: m_slots_set) {
            sum += size(slot);
        }
        return sum;
    }
    else {
        return size(0);
    }
}

bool DdbServer::IsMutiSlots()
{
    return m_mode == MODE_CLUSTER;
}

void DdbServer::AddSlots(IntPairList slots)
{
    for(const auto & item : slots) {
        add_slots(item.first, item.second);
    }

    mark_slots_changed_to_nodes(); // 将各节点标记为槽改变
}

const char *DdbServer::GetName()
{
    return m_normal_tcpserver->GetName();
}

const char *DdbServer::GetClusterServerName()
{
    return m_cluster_tcpserver->GetName();
}

std::string DdbServer::GetMasterName()
{
    return m_master->GetMasterName();
}

void DdbServer::GetInfo(DdbInfo *out_info)
{
    addinfo(out_info, "mode", to_mode_name(m_mode));
    addinfo(out_info, "state", to_state_name(m_state));
    addinfo(out_info, "normal server", m_normal_tcpserver->GetName());
    addinfo(out_info, "cluster server", m_cluster_tcpserver->GetName());
    addinfo(out_info, "master", m_master->GetMasterName());
    addinfo(out_info, "client count", std::to_string(m_server->m_clients.size()));
    addinfo(out_info, "slave count", std::to_string(m_server->m_slaves.size()));
    addinfo(out_info, "replication offset", std::to_string(m_repl_offset));
    addinfo(out_info, "db(slots) count", std::to_string(this->GetDbNum()));
    addinfo(out_info, "kv pair count", std::to_string(this->Size()));
}

void DdbServer::GetClusterInfo(DdbInfo *out_info, int flags)
{
    if(flags & DDB_INFO_FLAG_BASIC) {
        addinfo(out_info, "usable:", IsUsable()? "ok":"fail");
        addinfo(out_info, "local slots count", std::to_string(m_slots_set.size()));
        addinfo(out_info, "assigned slots info", GetSlotsInfo());
        addinfo(out_info, "assigned slots count", std::to_string(GetAssignedSlotsNum()));
        addinfo(out_info, "connect count", std::to_string(m_cluster->m_nodes.size()));
        addinfo(out_info, "nodes count", std::to_string(m_cluster->m_nodes_2.size()));
        addinfo(out_info, "pfail nodes count", std::to_string(m_cluster->m_pfail_nodes.size()));
        addinfo(out_info, "fail nodes count", std::to_string(m_cluster->m_fail_nodes.size()));
        addinfo(out_info, "votes count", std::to_string(m_cluster->m_votes_count));
        addinfo(out_info, "epoch", std::to_string(this->GetEpoch()));
    }
    if(flags & DDB_INFO_FLAG_NODE) {
        for(const auto & pair : m_cluster->m_nodes) {
            addinfo(out_info, pair.second->GetName(), pair.second->GetInfo());
        }
    }
}

void DdbServer::GetSyncState(ClusterSyncState *out_state)
{
    out_state->m_ip = m_normal_tcpserver->GetIp();
    out_state->m_main_port = m_normal_tcpserver->GetPort();
    out_state->m_cluster_port = m_cluster_tcpserver->GetPort();

    out_state->m_master_name = m_master->GetMasterName();
    out_state->m_repl_offset = m_repl_offset;
    out_state->m_slave_count = m_server->m_slaves.size();
    out_state->m_mac = 0; // todo

    out_state->m_slots_set = &m_slots_set; // 通过赋值地址避免拷贝

    out_state->m_flags = 0;
    if(m_state == S_MASTER) {
        out_state->m_flags |= CLUSTER_NODE_MASTER;
    }
    else if(m_state == S_SLAVE) {
        out_state->m_flags |= CLUSTER_NODE_SLAVE;
    }

    out_state->m_votes_count = m_cluster->m_votes_count;
}

int DdbServer::Set(DdbClient *client)
{
    char ** argv = client->GetArgv();
    std::string key = argv[1];
    std::string value = argv[2];
    int slot;

    if((slot = parse_slot_and_redirect(client, key)) < 0) return slot;

    set(slot, key, value);

    do_reply(client, "ok\n");

    return 0;
}

int DdbServer::Get(DdbClient *client)
{
    char ** argv = client->GetArgv();
    std::string key = argv[1];
    int slot;

    if((slot = parse_slot_and_redirect(client, key)) < 0) return slot;
    
    if(contain_key(slot, key)) {
        do_reply(client, get(slot, key) + "\n");
    }
    else {
        do_reply(client, std::string("cannot find key: ") + argv[1] + "\n");
    }

    return 0;
}

int DdbServer::SlaveOf(DdbClient *client)
{
    char ** argv = client->GetArgv();
    char *master_argv[MAX_ARG_NUM];
    char slots[CLUSTER_ALL_SLOTS_NUM / BYTE_BITS_NUM];
    std::string cmd, mode, reply;
    int ret, sfd, argc, data_num, i, port, len;
    DdbServer::State old_state;
    SocketBuffer *socket_buffer;
    long long repl_offset;
    bool is_ok;

    // 检查地址合法性
    if((ret = do_address_check(client, argv[1], argv[2])) != 0) return ret;
    // 解析port
    port = atoi(argv[2]);
    // 连接master
    sfd = connect_master(argv[1], (unsigned short)port);
    if(sfd == DDBER_EXISTED) {
        do_reply(client, "this master has been set.\n");
        return 0;
    }
    else if(sfd == DDBER_ANET) {
        do_reply(client, "net error: please check the net address.\n");
        return ret;
    }
    else if(sfd < 0) {
        do_reply(client, "unkown error.\n");
        return DDBER_UNKOWN;
    }

    // 设置状态为同步中
    old_state = m_state;
    m_state = DdbServer::S_SYNC;
    do_reply(client, "synchronizing with master...\n");
    // 发送同步命令
    cmd = "psync ? -1\n";
    SocketApi::send(sfd, cmd.c_str(), cmd.length());
    // 读取同步启动命令
    socket_buffer = MyResource::GetSocketBufferPool()->GetBuffer();
    SocketReader r(sfd, socket_buffer);
    cmd = r.Readline();
    if(cmd == "") {
        do_reply(client, "psync reply timeout\n");
        ret = DDBER_TIMEOUT;
        goto MildError;
    }
    if(!DdbClient::parse_cmd(cmd.data(), cmd.length(), master_argv, &argc)) {    
        do_reply(client, "fail to synchronize: command +fullresync format error\n");
        ret = DDBER_FORMAT;
        goto MildError;
    }
    if(argc != 4) {
        do_reply(client, "fail to synchronize: arguments num of command +fullresync error\n");
        ret = DDBER_ARG_NUM;
        goto MildError;
    }
    if (strcmp(master_argv[0], "+fullresync") != 0) {
        do_reply(client, "fail to synchronize: command is not +fullresync\n");
        ret = DDBER_ARG_NUM;
        goto MildError;
    }

    // 解析+fullresync命令参数
    mode = master_argv[1];
    data_num = my_strtoi(master_argv[2], &is_ok);
    if(!is_ok) {
        do_reply(client, "fail to synchronize: data num canont be parse\n");
        ret = DDBER_PARSE;
        goto MildError;
    }
    repl_offset = my_strtoll(master_argv[3], &is_ok);
    if(!is_ok) {
        do_reply(client, "fail to synchronize: replication offset canont be parse\n");
        ret = DDBER_PARSE;
        goto MildError;
    }

    // 目标节点是slave节点
    if(mode == "slave") {
        do_reply(client, "fail to synchronize: target is a slave\n");
        ret = DDBER_ILLEGAL;
        goto MildError;
    }
    // 模式不匹配
    if(to_mode_name(m_mode) != mode) {
        do_reply(client, "master mode don't match with slave mode\n");
        ret = DDBER_ILLEGAL;
        goto MildError;
    }
    // 根据master的模式重构数据库
    if(mode == "cluster") {
        m_master->m_master_mode = MODE_CLUSTER;
        // 同步slot信息数据
        len = CLUSTER_ALL_SLOTS_NUM / BYTE_BITS_NUM;
        if(r.ReadSomeBytes(slots, len) != len) {
            do_reply(client, "slots info reply timeout\n");
            ret = DDBER_TIMEOUT;
            goto MildError;
        }
        // 重置数据库
        release_dbs();
        create_cluster_dbs();
        // 根据槽信息添加DbDict
        for(int i = 0; i < CLUSTER_ALL_SLOTS_NUM; i++) {
            int byte_index = i / BYTE_BITS_NUM;
            int bit_index = i % BYTE_BITS_NUM;
            if(slots[byte_index] & (1 << bit_index)) {
                add_slot(i);
            }
        }
    }
    else if(mode == "normal") {
        m_master->m_master_mode = MODE_NORMAL;
        // 重置数据库
        release_dbs();
        create_normal_dbs();
    }
    else {
        do_reply(client, "fail to synchronize: master mode unkown\n");
        ret = DDBER_UNKOWN;
        goto MildError;
    }

    // 复制数据
    for(i=0; i<data_num; i++) {
        cmd = r.Readline();
        if(cmd == ""){
            do_reply(client, "data reply timeout\n");
            ret = DDBER_TIMEOUT;
            goto Error;
        }
        if(!DdbClient::parse_cmd(cmd.data(), cmd.length(), master_argv, &argc) || (argc != 2)) {
            do_reply(client, "fail to synchronize: data format error\n");
            ret = DDBER_FORMAT;
            goto Error;
        }

        Set(master_argv[0], master_argv[1]);
    }

    //设置偏移量
    m_repl_offset = repl_offset;
    
    // 关闭原来与主的连接, 并设置为新的连接描述符
    if(m_master->m_fd_to_master != -1) {
        close(m_master->m_fd_to_master);
    }
    m_master->m_fd_to_master = sfd;
    // 更新ip 和端口
    m_master->m_master_ip = argv[1];
    m_master->m_master_port = port;
    // 创建客户端
    if(m_master->m_client != nullptr) delete m_master->m_client;
    m_master->m_client = new DdbClient(this, 
        (char*)m_clients_reader.GetName(), sfd, socket_buffer);
    m_master->m_client->SetReplyEnable(false); // 从机在执行主机命令时，不回复
    m_master->m_client->SetFlags(
        m_master->m_client->GetFlags() | DDB_CLIENT_FLAG_REPLICATION); // 设置为复制模式
    m_master->m_client->DoRead(); // 尝试处理缓冲区剩下的数据
    // 将套接字添加到m_clients_reader，用于接收数据
    // 注意，这里沿用同步处理阶段的socket_buffer作为数据缓冲
    m_clients_reader.AddFd(sfd, socket_buffer);
    // 启动作为客户端的数据接收线程
    if(!m_clients_reader.IsRuning()) m_clients_reader.Start();

    // 回复客户设置完成
    do_reply(client, "finish synchronizing with master.\n");
    reply = std::string("this node is running as slave of ") + argv[1] + ": " + argv[2] + "\n";
    do_reply(client, reply);

    m_state = DdbServer::S_SLAVE;
    return 0; 

Error:
    m_master->Reset();
    // 重置数据库
    release_dbs();
    create_normal_dbs();
      
    close(sfd);
    m_state = DdbServer::S_MASTER;
    m_repl_offset = 0; // 重置偏移量
    printf("SlaveOf p6\n");
    return ret;

MildError: // 不会损坏slaveof前的数据和连接
    close(sfd);
    m_state = old_state;
    printf("SlaveOf p7\n");
    return ret;
}

void DdbServer::SlaveOf(std::string ip, unsigned short port)
{
    std::string cmd = "slaveof " + ip + " " + std::to_string(port);
    m_fake_client.ExecuteCmd(cmd);
}

int DdbServer::SlaveOfNoOne(DdbClient *client)
{
    SlaveOfNoOne();
    do_reply(client, "ok\n");

    return 0;
}

void DdbServer::SlaveOfNoOne()
{
    // 关闭原来与主的连接
    if(m_master->m_fd_to_master != -1) close(m_master->m_fd_to_master);
    // 复位m_master状态
    m_master->Reset();
    // 将自身状态设置为主
    m_state = DdbServer::S_MASTER;
}

int DdbServer::FullSync(DdbClient *client)
{
    int size;
    std::string relpy;
    char slots[CLUSTER_ALL_SLOTS_NUM / BYTE_BITS_NUM];

    auto send_sync_start = [&](std::string mode) {
        size = this->Size();
        relpy = "+fullresync " + mode + " " + std::to_string(size) + 
        " " + std::to_string(m_repl_offset) + "\n";
        do_reply(client, relpy);
    };

    if(GetState() == S_SLAVE) {
        send_sync_start("slave");
        // todo 清理client,虽然对方会关闭tcp进而触发清理
        return DDBER_ILLEGAL;
    }

    if(m_mode == MODE_CLUSTER) {
        // 发送同步开始命令
        send_sync_start("cluster");
        // 发送槽信息
        memset(slots, 0, sizeof(slots));
        for(unsigned short slot: m_slots_set) {
            int byte_index = slot / BYTE_BITS_NUM;
            int bit_index = slot % BYTE_BITS_NUM;
            slots[byte_index] |= (1 << bit_index);
        }
        SocketApi::send(client->GetSocketFd(), slots, sizeof(slots));
        // 发送键值对
        relpy = "";
        for(unsigned short slot: m_slots_set) {
            assert(slot < CLUSTER_ALL_SLOTS_NUM && slot >= 0);
            DdbDict * db_dict = m_dbs[slot];
            assert(db_dict != nullptr);
            for(DdbDictPair pair : (*db_dict)) {
                relpy += pair.first + " " + pair.second + "\n";
                if(relpy.length() >= 1024) {
                    do_reply(client, relpy);
                    relpy = "";
                }
            }
        }
        if(relpy != "") do_reply(client, relpy);
        // 将客户放入slave列表
        m_server->m_slaves[client->GetSocketFd()] = client;

        return 0;
    }
    else if(m_mode == MODE_NORMAL) {
        // 发送同步开始命令
        send_sync_start("normal");
        // 发送键值对
        relpy = "";
        for(DdbDictPair pair : (*m_dbs[0])) {
            relpy += pair.first + " " + pair.second + "\n";
            if(relpy.length() >= 1024) {
                do_reply(client, relpy);
                relpy = "";
            }
        }
        if(relpy != "") do_reply(client, relpy);
        // 将客户放入slave列表
        m_server->m_slaves[client->GetSocketFd()] = client;

        return 0;
    }

    return DDBER_UNKOWN;
}

int DdbServer::PartSync(DdbClient *client)
{
    return 0;
}

void DdbServer::Replicate(std::string &cmd)
{
    for(std::pair<int, DdbClient *> pair : m_server->m_slaves) {
        pair.second->DoReply(cmd.c_str(), cmd.length());
    }
}

void DdbServer::ReplicateToMaster(std::string &cmd)
{
    send_to_master(cmd.c_str(), cmd.length());
}

void DdbServer::FeedReplicateBuffer(std::string &cmd)
{
    m_repl_buf->WriteIn(cmd.data(), cmd.length());
    m_repl_offset += cmd.length();
}

int DdbServer::Meet(std::string ip, unsigned short port)
{
    if(port == 0) return DDBER_ANET;
    if(ip == "") return DDBER_ANET;
    
    std::string cluster_name = ip + ":" + std::to_string(port);
    if(m_cluster->m_nodes_3.count(cluster_name)) return DDBER_EXISTED;
    if(cluster_name == this->GetClusterServerName()) return DDBER_EXISTED;
    if(m_cluster->m_meeting_nodes.count(cluster_name)) return DDBER_EXISTED;

    int fd = SocketApi::connect(ip.c_str(), port, 0);
    if(fd < 0) return DDBER_ANET;

    SocketBuffer *sbuf = MyResource::GetSocketBufferPool()->GetBuffer();
    ClusterNode *new_node = new ClusterNode(this, fd, sbuf);
    new_node->SetClusterAddress(ip, port); // 提前设置地址，以便后续从m_meeting_nodes中移除
    new_node->SetAsClient();
    // 添加该节点，并启动异步接收
    AddNode(new_node);
    AddMeetingNode(new_node);
    m_clients_reader.AddFd(fd, sbuf);
    if(!m_clients_reader.IsRuning()) m_clients_reader.Start();
    // 发送meet命令
    new_node->Meet();

    return 0;
}

int DdbServer::do_address_check(DdbClient *client, std::string ip, std::string sport)
{
    // 解析port
    unsigned short port = atoi(sport.c_str());
    if(port <= 0) {
        do_reply(client, "port argument of port is invalid\n");
        return DDBER_ADDRESS;
    }

    // 地址与自己的normal server相同
    if((strcmp(m_normal_tcpserver->GetIp(), ip.c_str()) == 0) &&
        (m_normal_tcpserver->GetPort() == port)) {
        do_reply(client, "address must not be normal server address of self\n");
        return DDBER_ILLEGAL;
    }

    // 地址与自己的cluster server相同 
    if((strcmp(m_cluster_tcpserver->GetIp(), ip.c_str()) == 0) &&
        (m_cluster_tcpserver->GetPort() == port)) {   
        do_reply(client, "address must not be cluster server address of self\n");
        return DDBER_ILLEGAL;
    }

    return 0;
}

ClusterNode *DdbServer::GetFailNode(std::string name)
{
    const NodeNameDict &nodes = GetFailNodes();
    if(nodes.count(name)) {
        return nodes.at(name);
    }
    return nullptr;
}

void DdbServer::AddNode(ClusterNode *node)
{
    m_cluster->m_nodes[node->GetFd()] = node;

    // LogNode(node, "AddNode");
}

bool DdbServer::AddNode2(ClusterNode *node)
{
    // LogNode(node, "AddNode2");
    // 此段程序用于解决meet碰撞问题。两个节点同时meet对方时，如果接受，则由于连接的唯一性，
    // 双方都会在pong到来时关闭自己发起的meet（对方的meet先来了），导致两个连接都被关闭。
    // 优先保证自己发起的meet，如果发生同时meet的情况，最坏的结果就是两个连接都被移除。
    if(m_cluster->m_meeting_nodes.count(node->GetClusterName()) && !node->IsClient()) {
        RemoveNode(node);
        // LogNode(node, "AddNode2 fail, this node is meeting");
        return false;
    }

    RemoveMeetingNode(node);

    if(m_cluster->m_nodes_2.count(node->GetName())) {
        ClusterNode *old_node = m_cluster->m_nodes_2[node->GetName()];
        if(!old_node->IsValid()) {
            RemoveNode(old_node);
        }
        else {
            RemoveNode(node);
            // LogNode(node, "AddNode2 fail, this node is exist");
            return false;
        }
    }

    m_cluster->m_nodes_2[node->GetName()] = node;
    m_cluster->m_nodes_3[node->GetClusterName()] = node;
    // m_cluster->m_ping_time_set.emplace(node);
    AddNodeToPingSet(node);

    // LogNode(node, "AddNode2 ok");

    return true;
}

void DdbServer::AddNodeToPingSet(ClusterNode *node)
{
    if(!m_cluster->m_ping_time_set.count(node)) {
        // 随机化新节点在ping_set中的位置，以达到ping
        // 负载均匀(都在ping同一个节点)的目的
        int count = m_cluster->m_ping_time_set.size();
        int range = (count + 1)*(1000/5);
        int ping_time = mstime() - abs(mt_random()) % range;
        node->SetPingSent(ping_time);
        node->SetPongReceived(ping_time + 1);
        m_cluster->m_ping_time_set.emplace(node);
    }
}

void DdbServer::RemoveNode(ClusterNode *node)
{
    // todo 用at优化
    // name相同，node不一定相同
    NodeNameDict & nodes_2 = m_cluster->m_nodes_2;
    if(nodes_2.count(node->GetName()) && 
       nodes_2[node->GetName()] == node) {
        nodes_2.erase(node->GetName());
    }
    NodeNameDict & nodes_3 = m_cluster->m_nodes_3;
    if(nodes_3.count(node->GetClusterName()) &&
       nodes_3[node->GetClusterName()] == node) {
        nodes_3.erase(node->GetClusterName());
    }
        
    m_cluster->m_ping_time_set.erase(node);
    m_cluster->m_pfail_nodes.erase(node);

    std::string name = node->GetName();
    NodeNameDict & fail_nodes = m_cluster->m_fail_nodes;
    if(fail_nodes.count(name) &&
       fail_nodes.at(name) == node) {
        fail_nodes.erase(name);
    }
    // fd相同，node一定相同
    if(m_cluster->m_nodes.count(node->GetFd())) {
        m_cluster->m_nodes.erase(node->GetFd());
        release_socket(node->GetFd(), node->GetBuffer());
        m_cluster->m_to_delete_nodes.emplace(node);
    }

    RemoveMeetingNode(node); // 应对握手超时的情况

    // LogNode(node, "RemoveNode");
}

void DdbServer::MoveToFailSet(ClusterNode *node)
{
    m_cluster->m_pfail_nodes.erase(node);
    if(!m_cluster->m_fail_nodes.count(node->GetName())) {
        m_cluster->m_fail_nodes[node->GetName()] = node;
    }
}

void DdbServer::AddMeetingNode(ClusterNode *node)
{
    if(!m_cluster->m_meeting_nodes.count(node->GetClusterName())) {
        m_cluster->m_meeting_nodes[node->GetClusterName()] = node;
    }
}

void DdbServer::RemoveMeetingNode(ClusterNode *node)
{
    if(m_cluster->m_meeting_nodes.count(node->GetClusterName())) {
        if(m_cluster->m_meeting_nodes.at(node->GetClusterName()) == node) {
            m_cluster->m_meeting_nodes.erase(node->GetClusterName());
        }
    }
}

void DdbServer::UpdatePingTime(mstime_t new_time, ClusterNode *node)
{
    NodeTimeSet& set = m_cluster->m_ping_time_set;
    if(set.count(node)) {
        // todo感觉好怪啊
        set.erase(node);
        node->SetPingSent(new_time);
        set.emplace(node);
    }
}

void DdbServer::UpdateSlots(ClusterNode *node, UShortSet *slots)
{
    for(unsigned short slot: *slots) {
        update_cluster_slots(node, slot);
    }
}

void DdbServer::ClearSlots(UShortSet *slots)
{
    for(unsigned short slot: *slots) {
        update_cluster_slots(nullptr, slot);
    }
}

bool DdbServer::IsUsable()
{
    return m_cluster->m_assigned_slots_count == CLUSTER_ALL_SLOTS_NUM;
}

void DdbServer::FailToAll(std::string name)
{
    std::list<ClusterNode*> last_to_send;
    for(auto& pair: GetNodeNameDict()) {
        ClusterNode *node = pair.second;
        if(node->GetState() == S_NORMAL) {
            if(node->GetMasterName() == name) {
                last_to_send.push_back(node);
            }
            else {
                node->SendFail(name);
            }
        }  
    }
    // 最后发给挂掉节点的从节点
    for(auto& node: last_to_send) {
        node->SendFail(name);
    }
}

void DdbServer::FailoverRequest()
{
    if(m_cluster->m_is_voting) return;
    if(m_state != S_SLAVE) return;
    if(!m_cluster->m_fail_nodes.count(GetMasterName())) return;

    printf("%s: %s start send failover request\n", get_str_time().c_str(), GetName());

    m_cluster->m_is_voting = true;
    m_cluster->m_votes_count = 0;
    m_cluster->m_master_count = 0;
    m_cluster->m_electors.clear();

    ClusterNode * fail_node = GetFailNode(GetMasterName());
    if(!fail_node) return;

    NodeNameDict & nodes = GetNodeNameDict();
    for(auto & pair: nodes) {
        ClusterNode *node = pair.second;
        // 发送故障转移请求（拉选票）
        if(node->IsMaster() && node->GetState() == S_NORMAL) {
            m_cluster->m_master_count++; // 统计主节点数
            node->SendFailover(CLUSTERMSG_TYPE_FAILOVER_AUTH_REQUEST, 
                    fail_node->GetName(), fail_node->GetEpoch());
            // if(((node->GetPort() - 18100) / 4) % 4 == m_cluster_tcpserver->GetPort() % 4) {
            //     node->SendFailover(CLUSTERMSG_TYPE_FAILOVER_AUTH_REQUEST, 
            //     fail_node->GetName(), fail_node->GetEpoch());
            // }
        }
        // 收集兄弟节点（竞选对手，和本server同一个主的节点）
        if(GetState() == DdbServer::S_SLAVE && 
           node->GetState() == S_NORMAL &&
           GetMasterName() == node->GetMasterName()) {
            node->ResetVotesCount(); // 清空历史选票
            m_cluster->m_electors.emplace(node);        
        }
    }
    printf("%s: %s finish send failover request\n", get_str_time().c_str(), GetName());
}

void DdbServer::FailoverRequestDelayed()
{
    int delay = abs(mt_random()) % FAILOVER_REQUEST_MAX_DELAY;
    SetFqAlarm(delay);
}

void DdbServer::FailoverToAll(int msg_type, ClusterNode *fail_node)
{
    int epoch = fail_node->GetEpoch();
    std::string name = fail_node->GetName();
    std::list<ClusterNode*> last_to_send;

    for(auto& pair: GetNodeNameDict()) {
        ClusterNode * node = pair.second;
        if(node->GetState() == S_NORMAL) {
            if(node->GetMasterName() == name) {
                last_to_send.push_back(node);
            }
            else {
                node->SendFailover(msg_type, name, epoch);
            }       
        }
    }
    // 最后发给挂掉节点的从节点
    for(auto& node: last_to_send) {
        node->SendFailover(msg_type, name, epoch);
    }
}

void DdbServer::FinishVote()
{
    m_cluster->m_is_voting = false;
}

void DdbServer::SetFqAlarm(int ms)
{
    assert(GetEpoch() >= 0);
    m_fq_alarm->SetAlarm(GetEpoch(), ms);
}

int DdbServer::GetEpoch()
{
    if(m_state != S_SLAVE) return -1;
    ClusterNode * node = GetFailNode(GetMasterName());
    if(!node) return -1;

    return node->GetEpoch();
}

int DdbServer::GetAssignedSlotsNum()
{
    int count = 0;
    for(int i=0; i<CLUSTER_ALL_SLOTS_NUM; i++) {
        if(m_cluster->m_slots[i]) count++;
    }
    return count;
}

std::string DdbServer::GetSlotsInfo()
{
    std::string ret;
    ClusterNode *cur;
    ClusterNode * pre = nullptr;
    
    for(int i=0; i<CLUSTER_ALL_SLOTS_NUM; i++) {
        cur = m_cluster->m_slots[i];
        if(pre == nullptr && cur != nullptr) {
            ret += std::to_string(i);
        }
        else if(pre != nullptr && cur == nullptr) {
            ret += "~" + std::to_string(i - 1) + " ";
        }
        pre = cur;
    }
    if(pre != nullptr) {
        ret += "~" + std::to_string(CLUSTER_ALL_SLOTS_NUM - 1) + " ";
    }
    
    return ret;
}

int DdbServer::Test(DdbClient *client)
{
    // for(auto&pair: m_cluster->m_fail_nodes) {
    //     ClusterNode * node = pair.second;
    //     std::string reply = "name=" + node->GetName() + " ";
    //     reply = "epoch=" + std::to_string(node->GetEpoch()) + "\n";
    //     do_reply(client, reply);
    // }
    int argc = client->GetArgc();
    char **argv = client->GetArgv();

    if(argc > 1) {
        std::string name = std::string("192.168.227.128:") + argv[1];
        m_cluster->d_node_names.emplace(name);
    }

    return 0;
}

void DdbServer::on_event(DdbEvent *e)
{
    if(e->id & KV_DDB_EVENT_SOCKET){
        SockDataBase * sdata = (SockDataBase *)e->data;
        if(m_handler_map.count(sdata->server_name)) {
            m_handler_map[sdata->server_name]->on_event(e);
        }
    }
    else if(e->id & KV_DDB_EVENT_TIME) {
        if(e->id == KV_DDB_EVENT_TIMER_TIMEOUT) {
            m_timer_handler->on_event(e);
        }
        else if(e->id == KV_DDB_EVENT_DELAY_TIMEOUT) {
            m_fq_alarm->on_event(e);
        } 
    }
}

void DdbServer::cron()
{
    std::list<ClusterNode *> nodes;
    // 复制节点，避免遍历时改变集合本身
    for(const auto& it: m_cluster->m_nodes) {
        nodes.push_back(it.second);
    }
    // 执行遍历操作
    for(const auto& it: nodes) {
        // 小心，DoCron会移除m_cluster->m_nodes中的自己
        it->DoCron();
    }

    // delete节点
    for(const auto& node: m_cluster->m_to_delete_nodes) {
        delete node;
    }
    m_cluster->m_to_delete_nodes.clear();

    
    if(IsVoting()) {
        // 检查选举期间选票有没有被瓜分
        bool is_vote_ok = false;
        unsigned int sum = 0;
        for(auto& node : m_cluster->m_electors) {
            unsigned int voutes_count = node->GetVotesCount();
            if(voutes_count * 2 > GetMasterCount()) {
                is_vote_ok = true;
                break;
            }
            sum += voutes_count;
        }

        if(!is_vote_ok) {
            // 没有节点选票过半，但总选票过半，
            // 选票被瓜分，选举失败
            if(sum*2 >= GetMasterCount()) {
                // 结束本次选举
                FinishVote();

                ClusterNode *node = GetFailNode(GetMasterName());
                if(node) {
                    // 广播重新选举
                    FailoverToAll(CLUSTERMSG_TYPE_FAILOVER_REVOTE, node);
                    // 选举纪元增1                 
                    node->IncreaseEpoch();
                    // 发送故障转移请求(拉选票)
                    FailoverRequestDelayed();
                    // debug
                    printf("%s: %s broadcast vote fail\n", get_str_time().c_str(), GetName());
                }
            }
        }


        // 向竞选节点发送信息
        for(ClusterNode *node: m_cluster->m_electors) {
            ClusterNode *fnode = GetFailNode(GetMasterName());
            if(fnode) {
                node->SendFailover(CLUSTERMSG_TYPE_FAILOVER_INFO, 
                        fnode->GetName(), fnode->GetEpoch());
            } 
        }
    }


    // ping m_ping_sent值最老的5个节点
    mstime_t now;
    int count;
    const NodeTimeSet &set = GetPingTimeSet();
    std::list<ClusterNode *> ping_nodes;
    count = 0;
    now = mstime();
    for(const auto & node : set) {
        // 只处理上次ping已过去5秒的节点
        if(now - node->GetPingSent() < 5000) {
            break;
        }
        // 检查超时状态(上次ping已经过去)
        node->DoPingCheck();
        // 一次通常ping 5个节点
        if(count < 5) {
            ping_nodes.push_back(node);
            count++;
        }
        else { // 满5个节点后
            // 添加需要额外ping节点
            if(node->IsNeedAdditionalPing()) {
                ping_nodes.push_back(node);
                count++;
                if(count > 10) break;
            }
        }
    }
    // ping本身会改变NodeTimeSet，故放到循环外
    for(const auto & node : ping_nodes) {
        node->Ping();
    }
}

bool DdbServer::load_config(DdbServerConfig *config)
{
    config->ip = "192.168.227.128";
    config->main_port = 8000;
    config->cluster_port = config->main_port + CLUSTER_PORT_INC;
    config->mode = MODE_NORMAL;
    config->repl_buf_size = 1024*1024; // 1Mbyte
    return true;
}

int DdbServer::connect_master(const char *ip, unsigned short port)
{
    if(m_master->m_master_ip == std::string(ip) && m_master->m_master_port == port) {
        return DDBER_EXISTED;
    }
    // 连接远程服务器
    int fd = SocketApi::connect(ip, port, 0);
    if(fd == SOCKET_EER) fd = DDBER_ANET;

    return fd;
}

int DdbServer::send_to_master(const char *data, int len)
{
    if(m_master->m_fd_to_master < 0) return SOCKET_EER;
    return SocketApi::send(m_master->m_fd_to_master, data, len);
}

void DdbServer::create_dbs(int size)
{
    m_dbs = new DdbDict*[size];
    memset(m_dbs, 0, sizeof(DdbDict*) * size);
    m_dbs_size = size;
}

void DdbServer::release_dbs()
{
    if(m_dbs != nullptr) {
        for(int i=0; i<m_dbs_size; i++) {
            if(m_dbs[i]) delete m_dbs[i];
        }
        delete[] m_dbs;
    }

    m_dbs = nullptr;
    m_dbs_size = 0;
    m_slots_set.clear();
}

void DdbServer::create_normal_dbs()
{
    create_dbs(1);
    add_slot(0);
}

void DdbServer::create_cluster_dbs()
{
    create_dbs(CLUSTER_ALL_SLOTS_NUM);
}

int DdbServer::key_to_slot(std::string key)
{
    return crc(key) % CLUSTER_ALL_SLOTS_NUM;
}

int DdbServer::parse_slot(std::string key) {
    if(IsMutiSlots()) {
        int slot = key_to_slot(key);
        if(m_slots_set.count(slot)) return slot;
        else return -1;
    }
    else {
        return 0;
    }
}

static void dbs_assert(DdbDict**dbs, int slot) {
    assert(dbs != nullptr);
    assert(dbs[slot] != nullptr);
}

void DdbServer::set(int slot, std::string key, std::string value)
{
    dbs_assert(m_dbs, slot);
    (*m_dbs[slot])[key] = value;
}

std::string DdbServer::get(int slot, std::string key)
{
    dbs_assert(m_dbs, slot);
    return (*m_dbs[slot])[key];
}

void DdbServer::erase(int slot, std::string key)
{
    dbs_assert(m_dbs, slot);
    m_dbs[slot]->erase(key);
}

void DdbServer::clear(int slot)
{
    dbs_assert(m_dbs, slot);
    m_dbs[slot]->clear();
}

bool DdbServer::contain_key(int slot, std::string key)
{
    dbs_assert(m_dbs, slot);
    return m_dbs[slot]->count(key) != 0;
}

size_t DdbServer::size(int slot)
{
    dbs_assert(m_dbs, slot);
    return m_dbs[slot]->size();
}

int DdbServer::try_redirect(DdbClient *client, int slot)
{
    std::string reply;

    if(m_slots_set.count(slot)) return 0;
    if(slot >= CLUSTER_ALL_SLOTS_NUM) {
        do_reply(client, "error: slot out of range\n");
        return -1;
    }
    ClusterNode * node = m_cluster->m_slots[slot];
    if(node == nullptr) {
        do_reply(client, "error: cannot find node in charge of this slot\n");
        return -1;
    }

    reply = "redirect to " + node->GetName() + "\n";
    do_reply(client, reply);
    return 1;
}

int DdbServer::parse_slot_and_redirect(DdbClient *client, std::string key)
{
    int slot;

    if(IsMutiSlots()) {
        slot = key_to_slot(key);
        if(try_redirect(client, slot) != 0) return DDBER_NOT_EXIST;
    }
    else {
        slot = 0;
    }

    return slot;
}

void DdbServer::add_slot(int slot)
{
    assert(m_dbs != nullptr);
    if((slot >= m_dbs_size) || (slot < 0)) return;
    if(!m_dbs[slot]) {
        m_dbs[slot] = new DdbDict;
        m_slots_set.emplace(slot);
    }

    if(m_mode == MODE_CLUSTER) {
        update_cluster_slots(&m_cluster->m_self, slot);
    }
}

void DdbServer::remove_slot(int slot)
{
    assert(m_dbs != nullptr);
    if((slot >= m_dbs_size) || (slot < 0)) return;
    if(m_dbs[slot]) {
        delete m_dbs[slot];
        m_dbs[slot] = nullptr;
        m_slots_set.erase(slot);
    }

    if(m_mode == MODE_CLUSTER) {
        update_cluster_slots(nullptr, slot);
    }
}

void DdbServer::add_slots(int start_slot, int count)
{
    int end = std::min(start_slot + count, CLUSTER_ALL_SLOTS_NUM);
    for(int i=start_slot; i<end; i++) {
        add_slot(i);
    }
}

void DdbServer::mark_slots_changed_to_nodes()
{
    for(const auto & it: m_cluster->m_nodes) {
        it.second->SetSlotsChanged();
    }
}

void DdbServer::update_cluster_slots(ClusterNode *node, unsigned short slot)
{
    assert(slot < CLUSTER_ALL_SLOTS_NUM);
    if(m_cluster->m_slots[slot] == nullptr) m_cluster->m_assigned_slots_count++;
    if(node == nullptr) m_cluster->m_assigned_slots_count--;

    m_cluster->m_slots[slot] = node;
}

std::string DdbServer::to_mode_name(int mode)
{
    switch (mode)
    {
    case MODE_CLUSTER: return "cluster";
    case MODE_NORMAL: return "normal";
    default: return "unknow";
    }
}

std::string DdbServer::to_state_name(State state)
{
    switch (state)
    {
    case S_MASTER: return "master";
    case S_SLAVE: return "slave";
    default: return "unknow";
    }
}

void DdbServer::addinfo(DdbInfo *info, std::string name, std::string state)
{
    info->emplace_back(std::pair<std::string, std::string>(name, state));
}

static void release_socket(int fd, SocketBuffer *buffer) {
    close(fd);
    MyResource::GetSocketBufferPool()->ReturnBuffer(buffer);
}

void DdbServer::Server::on_event(DdbEvent *e)
{
    if(e->id == KV_DDB_EVENT_SOCKET_ACCEPTED){
        SockAcceptData *sdata = (SockAcceptData *)e->data;
        DdbClient *client = new DdbClient(m_server, 
                                sdata->server_name, sdata->sfd, (SocketBuffer *)sdata->data);
        m_clients[sdata->sfd] = client;
    }
    else if(e->id == KV_DDB_EVENT_SOCKET_READ){
        SockReadData *sdata = (SockReadData *)e->data;
        DdbClient *client = m_clients[sdata->sfd];
        if(client != nullptr) client->DoRead();
    }
    else if((e->id == KV_DDB_EVENT_SOCKET_READ_ERROR) || 
            (e->id == KV_DDB_EVENT_SOCKET_WRITE_ERROR)){
        SockErrorData *sdata = (SockErrorData*)e->data;

        if(m_clients.count(sdata->sfd)) {
            DdbClient *client = m_clients[sdata->sfd];
            m_clients.erase(sdata->sfd);
            m_slaves.erase(sdata->sfd);
            if(client != nullptr) delete client;
            // 放在if里以避免重复释放（SocketBuffer不支持重复释放）
            release_socket(sdata->sfd, (SocketBuffer *)sdata->data);
        }
    }
}

void DdbServer::Cluster::on_event(DdbEvent *e)
{
    if(e->id == KV_DDB_EVENT_SOCKET_ACCEPTED){
        SockAcceptData *sdata = (SockAcceptData *)e->data;
        ClusterNode *node = new ClusterNode(m_server, sdata->sfd, (SocketBuffer *)sdata->data);
        m_server->AddNode(node);
    }
    else if(e->id == KV_DDB_EVENT_SOCKET_READ){
        SockReadData *sdata = (SockReadData *)e->data;
        if(m_nodes.count(sdata->sfd)) {
            m_nodes[sdata->sfd]->DoRead();
        }
    }
    else if((e->id == KV_DDB_EVENT_SOCKET_READ_ERROR) || 
            (e->id == KV_DDB_EVENT_SOCKET_WRITE_ERROR)){
        SockErrorData *sdata = (SockErrorData*)e->data;

        if(m_nodes.count(sdata->sfd)) {
            m_nodes[sdata->sfd]->DoReadError();
        }
    }
}

void DdbServer::Master::on_event(DdbEvent *e)
{
    if(e->id == KV_DDB_EVENT_SOCKET_READ) {
        m_client->DoRead();
    }
    else if((e->id == KV_DDB_EVENT_SOCKET_READ_ERROR) ||
            (e->id == KV_DDB_EVENT_SOCKET_WRITE_ERROR)) {
        SockErrorData *sdata = (SockErrorData*)e->data;

        if(m_client != nullptr){
            delete m_client;
            m_client = nullptr;
            m_fd_to_master = -1;
            // 放在if里以避免重复释放（SocketBuffer不支持重复释放）
            release_socket(sdata->sfd, (SocketBuffer *)sdata->data);
        } 
    }
}

void DdbServer::Master::Reset()
{
    m_master_ip = "";
    m_master_port = 0;
    m_fd_to_master = -1;
    if(m_client != nullptr) {
        delete m_client;
        m_client = nullptr;
    }
    m_master_mode = MODE_NORMAL;
}

std::string DdbServer::Master::GetMasterName()
{
    if(m_master_ip == "") {
        return "";
    }
    else {
        return m_master_ip + ":" + std::to_string(m_master_port);
    }
}

void DdbServer::AsClients::on_event(DdbEvent *e)
{
    SockDataBase * sdata = (SockDataBase *)e->data;
    if(sdata->sfd == m_server->m_master->m_fd_to_master) {
        // 如果是master发来的数据，将事件转发给m_master
        m_server->m_master->on_event(e);
    }
    else {
        if(m_server->m_cluster->m_nodes.count(sdata->sfd)) {
            m_server->m_cluster->on_event(e);
        }
    }
    // todo 集群客户事件转发
}

DdbServer::SocketReader::SocketReader(int sfd, SocketBuffer *buffer)
    : m_sfd(sfd), m_buffer(buffer)
{
    assert(buffer != nullptr);

    m_epfd = epoll_create1(0);
    if (m_epfd == -1) {
        perror("epoll_create1");
    }

    struct epoll_event ev;
    ev.events = EPOLLIN;
    ev.data.fd = m_sfd;
    if (epoll_ctl(m_epfd, EPOLL_CTL_ADD, sfd, &ev) == -1) {
        perror("epoll_ctl: EPOLL_CTL_ADD");
    }
}

DdbServer::SocketReader::~SocketReader()
{
    close(m_epfd);
}

std::string DdbServer::SocketReader::Readline()
{
    int ret, start, end, i, offset, len;
    std::string line;
    bool flag;

    offset = 0;
    while(true) {  
        start = m_buffer->Start();
        end = m_buffer->End();
        if(end < start) end += m_buffer->Capacity();

        flag = false;
        for(i = start + offset; i < end; i++) {
            if(m_buffer->At(i) == '\n') {
                len = i - start + 1;
                line.resize(len + 1);
                m_buffer->ReadOut(line.data(), len);
                flag = true;
                break;
            }
        }
        if(flag) break;
        offset = end - start;
        
        ret = epoll_wait(m_epfd, m_events, 1, 5000);
        
        if(ret <= 0) {
            line = "";
            break;
        }

        ret = m_buffer->WriteIn(m_sfd);
        if(ret < 0) {
            perror("SocketReader::Readline WriteIn: ");
            line = "";
            break;
        }
    }

    return line;
}

int DdbServer::SocketReader::ReadSomeBytes(char *buf, int len)
{
    int ret, start, end;

    while(true) { 
        start = m_buffer->Start();
        end = m_buffer->End();
        if(end < start) end += m_buffer->Capacity();

        if(end - start < len) {
            ret = epoll_wait(m_epfd, m_events, 1, 5000);
            if(ret <= 0) {
                return -1;
            }
            ret = m_buffer->WriteIn(m_sfd);
            if(ret < 0) {
                perror("SocketReader::ReadSomeBytes WriteIn: ");
                return -1;
            }
        }
        else {
            m_buffer->ReadOut(buf, len);
            return len;
        }
    }
}

int DdbServer::SocketReader::WaitSomeBytes(int len)
{
    int ret, start, end;

    fd_set fdset;
    FD_ZERO(&fdset);
    FD_SET(m_sfd, &fdset);

    while(true) { 
        start = m_buffer->Start();
        end = m_buffer->End();
        if(end < start) end += m_buffer->Capacity();

        if(end - start < len) {
            ret = epoll_wait(m_epfd, m_events, 1, 5000);
            if(ret <= 0) {
                return -1;
            }
            ret = m_buffer->WriteIn(m_sfd);
            if(ret < 0) {
                perror("SocketReader::WaitSomeBytes WriteIn: ");
                return -1;
            }
        }
        else {
            break;
        }
    }

    return end - start;
}

void DdbServer::CronTimer::on_timeout()
{
    m_server->cron();
}

DdbServer::TimerHandler::TimerHandler(DdbServer *server)
    : m_server(server), m_cron_timer(server),
      m_timer_mng(&server->m_eloop)
{
    m_timer_mng.AddTimer(&m_cron_timer);
}

void DdbServer::TimerHandler::on_event(DdbEvent *e)
{
    m_timer_mng.on_event(e);
}

void DdbServer::FailoverRequestAlarm::on_event(DdbEvent *e)
{
    DelayData * edata = (DelayData *)e->data;
    
    long long timeout = ((DdbTimeEvent*)e)->timeout;
    long long now = mstime();
    // printf("%s: %s alarm event delay time=%lld\n", 
    //     get_str_time().c_str(), m_server->GetName(), now - timeout);

    int epoch_of_event = *((int*)edata->data);
    int epoch = m_server->GetEpoch();
    // 比较纪元，处在同一纪元才进一步处理
    if(epoch >=0 && epoch == epoch_of_event) {
        // 广播故障转移请求
        m_server->FailoverRequest();
    }

    // 释放数据
    if(edata->data) delete (int*)edata->data;
}

void DdbServer::FailoverRequestAlarm::SetAlarm(int epoch, int m_delay)
{
    long long timeout = mstime() + m_delay;
    int *data = new int;
    *data = epoch;
    EventHelper::PushDelayEvent(&m_server->m_eloop, data, timeout);
    // printf("%s: %s now=%lld fq delay=%d timeout=%lld\n", 
    //     get_str_time().c_str(), m_server->GetName(), mstime(), m_delay, timeout);
}
