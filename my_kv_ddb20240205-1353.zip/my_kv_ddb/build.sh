cd build
cmake ..
make
cd ..