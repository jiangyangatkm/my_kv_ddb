#include "ClusterNode.h"

#include <assert.h>
#include <string.h>
#include <list>
#include <vector>

#include "DdbServer.h"
#include "SocketApi.h"
#include "os_api.h"
#include "DdbErrorNo.h"
#include "MyResource.h"
#include "gadgets.h"
#include "EventHelper.h"

#define FLAG_PING_FOR_TEST 1

ClusterNode::ClusterNode(DdbServer *server, int sfd, SocketBuffer *buffer)
    : m_server(server), m_sfd(sfd), m_in_buffer(buffer), m_is_valid(true), 
    m_is_handshaking(true), m_ping_sent(CLUSTER_INVALID_TIME), 
    m_pong_received(CLUSTER_INVALID_TIME), m_data_received(CLUSTER_INVALID_TIME), 
    m_fail_time(CLUSTER_INVALID_TIME), m_recv_data_buf(nullptr), 
    m_read_state(READ_HEAD), m_is_slots_changed(true), m_is_client(false),
    m_ping_delay(CLUSTER_INVALID_TIME), m_state(S_NORMAL), m_is_voted(false),
    m_epoch(0)
{
    assert(sfd >=0);

    m_sync_state.m_slots_set = new UShortSet();
    m_ctime = mstime();
}

ClusterNode::~ClusterNode()
{
    delete m_sync_state.m_slots_set;
}

std::string ClusterNode::GetName()
{
    return m_sync_state.m_ip + ":" + std::to_string(m_sync_state.m_main_port);
}

std::string ClusterNode::GetClusterName()
{
    return m_sync_state.m_ip + ":" + std::to_string(m_sync_state.m_cluster_port);
}

void ClusterNode::SetClusterAddress(std::string ip, unsigned short port)
{
    m_sync_state.m_ip = ip;
    m_sync_state.m_cluster_port = port;
}

bool ClusterNode::IsNeedAdditionalPing()
{
    bool bl = false;
    // 对于有错误报告的正常节点，尽快ping一次以确认实际状态
    if(m_state == S_NORMAL && m_pfail_reports.size() > 0) {
        bl = true;
    }
    return bl;
}

bool ClusterNode::IsMaster()
{
    return m_sync_state.m_master_name == "";
}

void ClusterNode::DoRead() // todo 数据读取的超时处理
{
    if(!m_is_valid) return;

    int start = m_in_buffer->Start();
    int end = m_in_buffer->End();
    int capacity = m_in_buffer->Capacity();
    int len, offset;
    if(start > end) end += capacity;

    if(m_read_state == READ_HEAD) {
        len = sizeof(m_recv_head);
        if(end - start >= len) {
            m_in_buffer->ReadOut((char*)&m_recv_head, len);
            if(m_recv_head.totlen < sizeof(m_recv_head) + 2) {
                m_is_valid = false;
                m_server->LogNode(this, "READ_HEAD fail: tol_len too short");
                return;
            }
            m_read_state = READ_DATA;
            m_res_data_count = m_recv_head.totlen - sizeof(m_recv_head);
            m_read_data_count = 0;
            m_recv_data_buf = new char[m_res_data_count];
            // 如果缓冲区中还有数据，则模拟发出一个读事件，以继续处理
            if(m_in_buffer->Start() != m_in_buffer->End()) {
                send_read_event();
            }
        }
        else return;// 缓冲区数据不足不做任何处理
    }
    else if(m_read_state == READ_DATA) {
        len = m_res_data_count;         
        len = m_in_buffer->ReadOut(m_recv_data_buf + m_read_data_count, len);
        m_res_data_count -= len;
        m_read_data_count += len;
        if(m_res_data_count == 0) { // 全部数据读入， 开始数据处理
            m_recv_head.slots = (uint16_t*)m_recv_data_buf;
            offset = (m_recv_head.slots[0] + 1) * sizeof(uint16_t);
            if(offset > m_read_data_count) { // 槽数据越界
                m_is_valid = false;
                delete []m_recv_data_buf;
                m_server->LogNode(this, "READ_DATA fail: slots num over message");
                return;
            }
            else {
                if(offset == m_read_data_count) m_recv_head.data = nullptr;
                else m_recv_head.data = (clusterMsgData*)(m_recv_data_buf + offset);

                process_clustermsg(&m_recv_head);
                delete []m_recv_data_buf;

                m_read_state = READ_HEAD;
                // 如果缓冲区中还有数据，则模拟发出一个读事件，以继续处理
                if(m_in_buffer->Start() != m_in_buffer->End()) {
                    send_read_event();
                }
            }
        }
        else if(m_res_data_count > 0) {
            return; // 数据未读完，返回等待下一波数据
        } 
        else {
            delete []m_recv_data_buf;
            m_is_valid = false; // 发生未知的错误
            m_server->LogNode(this, "READ_DATA fail: it can't happen");
            return;
        }
    }
}

void ClusterNode::DoReadError()
{
    m_is_valid = false;
    // SocketApi::close(m_sfd); // 在这里及时关闭， 否则就要在清理时才关闭
    // m_server->LogNode(this, "link error: node close the socket");

    if(m_is_handshaking) {
        // 如果还在握手，则尽快移除该节点，否则该节点会驻留在正在握手
        // 的集合里长达5秒，导致5秒内本node对应的连接没法被再次建立了。
        m_server->RemoveNode(this);
    }
}

void ClusterNode::DoCron()
{
    mstime_t now = mstime();
    
    int flags = m_sync_state.m_flags;
    if(m_is_handshaking) { // 检测meet超时
        if(now - m_ctime > 5000) {
            m_is_valid = false;
            m_server->LogNode(this, "handshaking timeout");
            m_server->RemoveNode(this);
            return;
        }
    }
    else {
        // if(!m_is_valid) return;
        // // 本节点在选举期间，向同主从群中其他正常子节点发送状态
        // if(m_server->IsVoting()) {
        //     if(m_server->GetState() == DdbServer::S_SLAVE && 
        //        m_state == S_NORMAL &&
        //        m_server->GetMasterName() == m_sync_state.m_master_name) {
        //         Pong();
        //     }
        // }
    }
}

void ClusterNode::DoPingCheck()
{
    if(m_ping_sent > m_pong_received) {
        m_ping_delay = -2; // 与初值区分
        if(S_NORMAL == m_state) {
            char info[LOG_MAX_LEN];
            snprintf(info, sizeof(info), 
                "pfail: pong received timeout");
            m_server->LogNode(this, info);
            m_state = S_PFAIL;
            m_server->AddPfailNode(this);
        }
    }
    else {
        m_ping_delay = m_pong_received - m_ping_sent;
        if(S_PFAIL == m_state) {
            m_server->LogNode(this, "out pfail: node ok again");
            m_state = S_NORMAL;
            m_server->RemovePfailNode(this);
        }
    }
}

void ClusterNode::Ping()
{
    ping(CLUSTERMSG_TYPE_PING);
}

void ClusterNode::Pong()
{
    ping(CLUSTERMSG_TYPE_PONG);
}

void ClusterNode::Meet()
{
    ping(CLUSTERMSG_TYPE_MEET);
}

void ClusterNode::SendFail(std::string name)
{
    MsgBlock block(this, CLUSTERMSG_TYPE_FAIL, sizeof(clusterMsgDataFail));
    clusterMsg *msg = block.GetMsg();
    msg->count = 1;
    strcpy(msg->data->fail.about.nodename, name.c_str());
    send_msg(&block, m_sfd);
}

void ClusterNode::SendFailover(int msg_type, std::string name, int epoch)
{
    MsgBlock block(this, msg_type, sizeof(clusterMsgDataFailover));
    clusterMsg *msg = block.GetMsg();
    msg->count = 1;
    msg->data->failover.about.epoch = epoch;
    strcpy(msg->data->failover.about.nodename, name.c_str());

    // if(msg_type == CLUSTERMSG_TYPE_FAILOVER_FINISH) {
    //     printf("%s: start send failover finish to %s\n", get_str_time().c_str(), GetName().c_str());
    //     send_msg(&block, m_sfd);
    //     printf("%s: end send failover finish to %s\n", get_str_time().c_str(), GetName().c_str());
    //     return;
    // }

    send_msg(&block, m_sfd);
}

std::string ClusterNode::GetInfo()
{
    std::stringstream info;
    mstime_t now = mstime(); 
    // info<<"flag=" + std::to_string(m_sync_state.m_flags) + " ";
    // info<<"state=" + std::to_string(m_state) + " ";
    // info<<"slots=" + get_slots_info() + " ";
    info<<"ping_delay=" + std::to_string(m_ping_delay) + " ";
    info<<"now2ping=" + std::to_string(now - m_ping_sent)+ " ";
    info<<"now2pong=" + std::to_string(now - m_pong_received)+ " ";
    info<<"rbuf=" + std::to_string(SocketApi::get_bytes_num_in_rbuffer(m_sfd))+ " ";
    info<<"inbuf=" + std::to_string(m_in_buffer->Size())+ " ";
    // info<<"pfail_reports=" + std::to_string(m_pfail_reports.size()) + " ";
    // info<<"votes=" + std::to_string(m_sync_state.m_votes_count) + " ";
    // info<<std::string("valid=") + (m_is_valid ? "true":"false");
    return info.str();
}

std::string ClusterNode::GetInfoDetail()
{
    return std::string();
}

void ClusterNode::ping(int msg_type, int flags)
{
    const int MAX_PFNODES_TO_SEND = 5;

    int fresh_nodes_num, i, tol_node_num;
    // std::set<ClusterNode*> nodes_to_send;
    NodeNameDict &nodes_dict = m_server->GetNodeNameDict();
    NodeSet &pfail_nodes = m_server->GetPfailNodes();
    mstime_t old_time;

    if((msg_type != CLUSTERMSG_TYPE_PING) && 
       (msg_type != CLUSTERMSG_TYPE_PONG) &&
       (msg_type != CLUSTERMSG_TYPE_MEET)) return;
       
    // 测试ping时，不带任何Gossip，以提高效率
    if(flags & FLAG_PING_FOR_TEST) {
        MsgBlock block(this, msg_type, 0);
        m_server->UpdatePingTime(mstime(), this); // 包含了对m_ping_sent的修改
        send_msg(&block, m_sfd);
        return;
    }
    // 计算所需的数据空间
    // 取节点数的1/10以确保传播速度，
    // 如果节点的1/10少于3个节点，取3个节点，
    // 如果按上述规则取得的节点数多于总节点数，则取全部剩余节点
    tol_node_num = nodes_dict.size();
    if(!m_is_handshaking) tol_node_num--; // 去掉自己
    fresh_nodes_num = tol_node_num / 10;
    fresh_nodes_num = std::max(3, fresh_nodes_num); 
    fresh_nodes_num = std::min(tol_node_num, fresh_nodes_num);

    std::vector<ClusterNode*> nodes_to_send(fresh_nodes_num);
    NodeSet pfnodes_in_fresh;
    // 随机选取1/10的节点放入nodes_to_send
    if(fresh_nodes_num == tol_node_num) { // 优化全部节点都要选的情况
        i = 0;
        for(auto it: nodes_dict) {
            if(it.second != this) {
                nodes_to_send[i] = it.second;
                if(it.second->GetState() == S_PFAIL) {
                    pfnodes_in_fresh.emplace(it.second);
                }
                i++;
            }
        }
    }
    else {
        int n = abs(mt_random()) % nodes_dict.size();
        auto it_begin = nodes_dict.begin();
        auto it_end = nodes_dict.end();
        auto it = std::next(it_begin, n);
        i = 0;
        while(i < fresh_nodes_num) {
            if(it == it_end) it = it_begin;
            if(it->second != this) {
                nodes_to_send[i] = it->second;
                if(it->second->GetState() == S_PFAIL) {
                    pfnodes_in_fresh.emplace(it->second);
                }
                i++;
            }
            it++;
        }
    }
    // 将pfail节点放入nodes_to_send，以加快故障节点的检测速度
    // 由于nodes_to_send是集合，所以不会重复，为了避免节点太多
    // 而崩溃，最多带5个节点
    int count = pfnodes_in_fresh.size();
    for(auto it : pfail_nodes) {
        if(count >= 5)  break;
        if(!pfnodes_in_fresh.count(it)) {
            nodes_to_send.push_back(it);
            count++;
        }  
    }

    // 构造并发送报文
    MsgBlock block(this, msg_type, nodes_to_send.size() * sizeof(clusterMsgDataGossip));
    block.GetMsg()->count = nodes_to_send.size();
    i = 0;
    for(auto it: nodes_to_send) {
        block.SetGossip(i, it);
        i++;
    }

    if(msg_type != CLUSTERMSG_TYPE_PONG) {
        m_server->UpdatePingTime(mstime(), this); // 包含了对m_ping_sent的修改
    } 
    send_msg(&block, m_sfd);

    // debug
    // if(msg_type == CLUSTERMSG_TYPE_PING) {
    //     d_last_ping_size = block.GetTotalLen();
    //     // m_server->LogNode2(this, "ping send");
    // }
    // else if(msg_type == CLUSTERMSG_TYPE_PONG) {
    //     // m_server->LogNode2(this, "pong send");
    // }
}

void ClusterNode::send_msg(MsgBlock *block, int sfd)
{
    if(m_is_valid) {
        block->SendData(sfd);
    }
    m_is_slots_changed = false;
    
}

int ClusterNode::process_clustermsg(clusterMsg *msg)
{
    int ret = 0;
    // 验证消息合法性
    if((ret = verify_message(msg)) != 0) {
        m_is_valid = false;
        m_server->LogNode(this, "verify_message fail");
        return ret;
    }
    // 更新节点状态
    update_node_state(msg);
    // 处理消息数据
    switch (msg->type)
    {
    case CLUSTERMSG_TYPE_MEET:
    case CLUSTERMSG_TYPE_PING:
    case CLUSTERMSG_TYPE_PONG: 
        ret = process_ping(msg); 
        break;
    case CLUSTERMSG_TYPE_FAIL: 
        ret = process_fail(msg); 
        break;
    case CLUSTERMSG_TYPE_FAILOVER_AUTH_REQUEST:
    case CLUSTERMSG_TYPE_FAILOVER_AUTH_ACK:
    case CLUSTERMSG_TYPE_FAILOVER_FINISH:
    case CLUSTERMSG_TYPE_FAILOVER_REVOTE:
    case CLUSTERMSG_TYPE_FAILOVER_INFO:
        ret = process_failover(msg);
        break;
    default: break;
    }

    if(ret != 0) return ret;

    update_slots(msg);

    m_data_received = mstime();
    return ret;
}

int ClusterNode::process_ping(clusterMsg *msg)
{
    // if(CLUSTERMSG_TYPE_PING == msg->type) {
    //     m_server->LogNode2(this, "ping recv");
    // }
    // else if(CLUSTERMSG_TYPE_PONG == msg->type) {
    //     m_server->LogNode2(this, "pong recv");
    // }

    if((CLUSTERMSG_TYPE_MEET == msg->type) ||
       (CLUSTERMSG_TYPE_PONG == msg->type)) {
        if(m_is_handshaking) {
            if(!m_server->AddNode2(this)) { // 添加失败，标记为无效+可移除
                m_is_valid = false;
                return DDBER_EXISTED;
            }
            m_is_handshaking = false;

            m_pong_received = mstime() - 1; // 解决首次ping时，pong时间为-1的问题
        }

        if(CLUSTERMSG_TYPE_PONG == msg->type) {
            m_pong_received = mstime();
        }      
    }
    // 处理gossip
    process_gossip(msg);
    // 回复pong
    if((msg->type == CLUSTERMSG_TYPE_MEET) ||
       (msg->type == CLUSTERMSG_TYPE_PING)) {
        Pong();
    }

    return 0;
}

int ClusterNode::process_fail(clusterMsg *msg)
{
    NodeNameDict &nodes = m_server->GetNodeNameDict();
    char *fault_node_name = msg->data->fail.about.nodename;
    if(nodes.count(fault_node_name)) {
        ClusterNode *node = nodes.at(fault_node_name);
        if(node->m_state != S_FAIL) {
            node->set_fail();
            // 判断故障节点是否为主节点
            if(node->IsMaster()) {
                // 自己的主恰好是故障节点，随机延迟一段时间后，发起failover请求
                if(m_server->GetState() == DdbServer::S_SLAVE &&
                m_server->GetMasterName() == fault_node_name) {
                    m_server->FailoverRequestDelayed();
                }
            }
            else { // 从节点，直接移除
                m_server->RemoveNode(node);
            }
        }
    }

    return 0;
}

int ClusterNode::process_failover(clusterMsg *msg)
{
    int ret;

    int msg_epoch = msg->data->failover.about.epoch;
    std::string node_name = msg->data->failover.about.nodename;
    ClusterNode *node = nullptr;
    if((node = get_fail_node(node_name)) != nullptr && 
        node->m_epoch == msg_epoch) {

        // 更新选票信息
        // 为了防止不同epoch的选票信息相互影响，只在收到合法
        // failover报文时更新选票信息
        m_sync_state.m_votes_count = msg->votes_count;

        switch (msg->type)
        {
        case CLUSTERMSG_TYPE_FAILOVER_AUTH_REQUEST:
            ret = process_failover_request(msg, node);
            break;
        case CLUSTERMSG_TYPE_FAILOVER_AUTH_ACK:
            ret = process_failover_ack(msg, node);
            break;
        case CLUSTERMSG_TYPE_FAILOVER_FINISH:
            ret = process_failover_finish(msg, node);
            break;
        case CLUSTERMSG_TYPE_FAILOVER_REVOTE:
            ret = process_failover_revote(msg, node);
            break;
        case CLUSTERMSG_TYPE_FAILOVER_INFO:
            ret = 0;
            break; 
        default:
            ret = DDBER_ILLEGAL;
            break;
        }
    }

    return ret;
}

int ClusterNode::process_failover_request(clusterMsg *msg, ClusterNode *fnode)
{
    // 非主节点没有投票权
    if(m_server->GetState() != DdbServer::S_MASTER) return 0;

    // 确保针对名称为node_name的故障节点只投出一次选票
    if(!fnode->IsVoted()) {
        fnode->SetVotedState(true);
        SendFailover(CLUSTERMSG_TYPE_FAILOVER_AUTH_ACK, fnode->GetName(), fnode->m_epoch);
    }

    return 0;
}

int ClusterNode::process_failover_ack(clusterMsg *msg, ClusterNode *fnode)
{
    // 确保选票与故障节点一致（目前应该不可能不一致）
    if(m_server->GetMasterName() == fnode->GetName()) {
        m_server->IncreaseVotes();
        // IsVoting和FinishVote确保交接完成的代码不会重复触发
        if(m_server->IsVoting() &&
            (m_server->GetVotesCount() * 2 > m_server->GetMasterCount())) {
            m_server->FinishVote();
            printf("%s: %s is elected\n", get_str_time().c_str(), m_server->GetName());
            // 将自己改成主, 以便接收从节点，槽信息也可以被更新
            m_server->SlaveOfNoOne();
            printf("%s: %s becomes a master\n", get_str_time().c_str(), m_server->GetName());
            // 标记槽为已改变，以便各节点在收到选举结束时更新负责槽
            m_server->MarkNodesSlotsChanged();
            // 宣布交接完成
            send_failover_finish_to_all(fnode);
            // 移除故障节点
            m_server->RemoveNode(fnode);

            printf("%s: %s finish failover\n", get_str_time().c_str(), m_server->GetName());
        }
    }
    return 0;
}

int ClusterNode::process_failover_finish(clusterMsg *msg, ClusterNode *fnode)
{
    // 本节点是故障节点的子节点
    if(m_server->GetMasterName() == fnode->GetName()) {
        // 结束选举过程
        m_server->FinishVote();
        // 将本节点设置为获胜节点的从节点
        std::string master_ip = msg->myip;
        unsigned short master_port = msg->port;
        m_server->SlaveOf(master_ip, master_port);
        printf("%s: %s becomes slave of %s\n", 
            get_str_time().c_str(), m_server->GetName(), m_server->GetMasterName().c_str());
    }
    // 移除故障节点
    m_server->RemoveNode(fnode);
    return 0;
}

int ClusterNode::process_failover_revote(clusterMsg *msg, ClusterNode *fnode)
{
    fnode->SetVotedState(false); // 重置选票
    fnode->IncreaseEpoch(); // 纪元增1
    // 本节点是故障节点的子节点
    if(m_server->GetMasterName() == fnode->GetName()) {
        m_server->FinishVote();
        m_server->FailoverRequestDelayed();
    }
    return 0;
}

int ClusterNode::process_gossip(clusterMsg *msg)
{
    int i;
    clusterMsgDataGossip *g;
    // 处理Gossip
    NodeNameDict &nodes = m_server->GetNodeNameDict();
    g = msg->data->ping.gossip;
    for(i = 0; i < msg->count; i++) {
        NodeNameDict::iterator it = nodes.find(g->nodename);
        if(it != nodes.end()) { 
            ClusterNode *node = it->second;
            if(g->state == S_PFAIL) { // 处理PFail节点
                node->add_pfail_report(this->GetName());
            }
            else if(g->state == S_NORMAL) {
                node->remove_pfail_report(this->GetName());
            }
            else if(g->state == S_FAIL) {

            }
        }
        else {
            // meet新节点
            if((strcmp(g->nodename, m_server->GetName()) != 0) &&
               (g->state == S_NORMAL)) {
                m_server->Meet(g->ip, g->cport);
            }
        }
        g++;
    }

    return 0;
}

int ClusterNode::verify_message(clusterMsg *msg)
{
    int real_len, head_slots_len;
    int tp = msg->type;
    // 验证报文头
    if(msg->sig[0] != 'D' || msg->sig[1] != 'd' || 
       msg->sig[2] != 'b' || msg->sig[3] != 's') {
        return DDBER_FORMAT;
    }

    // 验证各类型消息
    head_slots_len = sizeof(clusterMsg) + (msg->slots[0] + 1) * sizeof(msg->slots[0]);
    if((CLUSTERMSG_TYPE_MEET == tp) || (CLUSTERMSG_TYPE_PING == tp) ||
        (CLUSTERMSG_TYPE_PONG == tp)) {
        real_len = msg->count * sizeof(clusterMsgDataGossip) + head_slots_len;
        if(real_len != msg->totlen) {
            return DDBER_FORMAT;
        }
    }
    else if(CLUSTERMSG_TYPE_FAIL == tp) {
        real_len = sizeof(clusterMsgDataFail) + head_slots_len;
        if(real_len != msg->totlen) {
            return DDBER_FORMAT;
        }
    }

    return 0;
}

void ClusterNode::update_node_state(clusterMsg *msg)
{
    m_sync_state.m_ip = msg->myip;
    m_sync_state.m_main_port = msg->port;
    m_sync_state.m_cluster_port = msg->cport;
    m_sync_state.m_repl_offset = msg->offset;
    m_sync_state.m_master_name = msg->slaveof;
    m_sync_state.m_slave_count = msg->slave_count;
    m_sync_state.m_mac = msg->mac;
    m_sync_state.m_flags = msg->flags;
    // m_sync_state.m_votes_count = msg->votes_count;
}

void ClusterNode::update_slots(clusterMsg *msg)
{
    if(!msg->is_slots_valid) return;
    // 反序列化slots
    if(m_sync_state.m_slots_set != nullptr) {
        int slot_count = msg->slots[0];
        m_sync_state.m_slots_set->clear();
        for(int i = 1; i <= slot_count; i++) {
            m_sync_state.m_slots_set->emplace(msg->slots[i]);
        }
    }
    // 更新槽的负责节点数组，从节点的槽信息不更新
    if(m_sync_state.m_flags & CLUSTER_NODE_MASTER) {
        // 主节点的槽信息不更新到从节点 todo测试
        if(m_server->GetState() == DdbServer::S_MASTER ||
           m_server->GetMasterName() != GetName()) {
            m_server->UpdateSlots(this, m_sync_state.m_slots_set);
        }
    }
}

void ClusterNode::send_read_error_event()
{
    EventHelper::PushReadErrorEvent(
        m_server->GetEventLoop(), m_sfd, 
        (char*)m_server->GetClusterServerName(), m_in_buffer, 0);
}

void ClusterNode::send_read_event()
{
    EventHelper::PushReadEvent(
        m_server->GetEventLoop(), m_sfd, 
        (char*)m_server->GetClusterServerName(), m_in_buffer);
}

void ClusterNode::add_pfail_report(std::string name)
{
    m_pfail_reports.emplace(name);

    // 接收到半数以上节点的pfail报告
    if(m_pfail_reports.size()*2 > m_server->GetNodeNameDict().size()) {
        if(m_state != S_FAIL) { // 避免重复广播
            set_fail();
            // 广播节点失败的消息
            send_fail_to_all(this->GetName());
            // 如果发现故障的节点恰好是故障节点的从节点
            // 则自行发起选举（因为没人通知它节点故障）
            if(m_server->GetState() == DdbServer::S_SLAVE &&
               m_server->GetMasterName() == this->GetName()) {
                // 随机延迟一段时间后广播故障转移请求
                m_server->FailoverRequestDelayed();
            }
        }
    }
}

void ClusterNode::remove_pfail_report(std::string name)
{
    m_pfail_reports.erase(name);
}

void ClusterNode::set_fail()
{
    m_is_valid = false;
    m_state = S_FAIL;
    m_server->MoveToFailSet(this);
    // 如果是主节点，清除其负责的槽
    if(m_sync_state.m_flags & CLUSTER_NODE_MASTER) {
        // 如果故障节点为本节点的主节点，则不必清除槽
        if(m_server->GetMasterName() != this->GetName()) {
            m_server->ClearSlots(m_sync_state.m_slots_set);
        }
    }
}

void ClusterNode::send_fail_to_all(std::string name)
{
    m_server->FailToAll(name);
}

void ClusterNode::send_failover_finish_to_all(ClusterNode *fail_node)
{
    m_server->FailoverToAll(CLUSTERMSG_TYPE_FAILOVER_FINISH, fail_node);
}

ClusterNode *ClusterNode::get_fail_node(std::string name)
{
    return m_server->GetFailNode(name);
}

std::string ClusterNode::get_slots_info()
{
    std::string ret;
    char pre, cur;
    char slots[CLUSTER_ALL_SLOTS_NUM];
    memset(slots, 0, sizeof(slots));
    for(unsigned short slot: *m_sync_state.m_slots_set) {
        slots[slot] = 1;
    }
    
    pre = 0;
    for(int i=0; i<CLUSTER_ALL_SLOTS_NUM; i++) {
        cur = slots[i];
        if(pre == 0 && cur != 0) {
            ret += std::to_string(i);
        }
        else if(pre != 0 && cur == 0) {
            ret += "~" + std::to_string(i - 1) + " ";
        }
        pre = cur;
    }
    if(pre != 0) {
        ret += "~" + std::to_string(CLUSTER_ALL_SLOTS_NUM - 1) + " ";
    }
    
    return ret;
}

ClusterNode::MsgBlock::MsgBlock(ClusterNode *node, int msg_type, int msg_len)
    : m_node(node), m_msg_len(msg_len)
{
    int slot_data_size, slots_num, i;
    bool is_slots_valid;
    assert(node != nullptr);

    
    DdbServer *server = node->m_server;
    ClusterSyncState state; // 本节点的状态
    server->GetSyncState(&state);
    is_slots_valid = node->m_is_slots_changed && (server->GetState() == DdbServer::S_MASTER);
    slots_num = is_slots_valid ? state.m_slots_set->size() : 0;
    slot_data_size = (slots_num + 1) * sizeof(unsigned short);
    m_tot_len = sizeof(clusterMsg) + slot_data_size + msg_len;
    m_buf = new char[m_tot_len];
    m_msg = (clusterMsg*) m_buf;
    // 初始化头
    m_msg->sig[0] = 'D';
    m_msg->sig[1] = 'd';
    m_msg->sig[2] = 'b';
    m_msg->sig[3] = 's';
    m_msg->totlen = m_tot_len;
    m_msg->ver = CLUSTER_PROTO_VER;
    m_msg->port = state.m_main_port;
    m_msg->type = msg_type;
    m_msg->count = 0;
    m_msg->offset = state.m_repl_offset;
    strcpy(m_msg->slaveof, state.m_master_name.c_str());
    strcpy(m_msg->myip, state.m_ip.c_str());
    m_msg->cport = state.m_cluster_port;
    m_msg->flags = state.m_flags;
    m_msg->votes_count = state.m_votes_count;
    // 处理slots
    m_msg->is_slots_valid = is_slots_valid;
    // 这两个字段在反序列化时需要重新赋值
    m_msg->slots = (uint16_t*)(m_buf + sizeof(clusterMsg));
    m_msg->data = (clusterMsgData*)(m_buf + sizeof(clusterMsg) + slot_data_size);
    // 序列化slots
    m_msg->slots[0] = slots_num;
    if(is_slots_valid) {
        i = 1;
        for(unsigned short slot : *state.m_slots_set) {
            m_msg->slots[i] = slot;
            i++;
        }
    }
}

ClusterNode::MsgBlock::~MsgBlock()
{
    delete[] m_buf;
}

int ClusterNode::MsgBlock::SendData(int sfd)
{
    return SocketApi::send(sfd, m_buf, m_tot_len);
}

bool ClusterNode::MsgBlock::SetGossip(int i, ClusterNode *node)
{
    if((i + 1) * sizeof(clusterMsgDataGossip) > m_msg_len) return false;

    clusterMsgDataGossip * g = m_msg->data->ping.gossip + i;
    strcpy(g->nodename, node->GetName().c_str());
    g->ping_sent = node->m_ping_sent / 1000;
    g->pong_received = node->m_pong_received / 1000;
    strcpy(g->ip, node->m_sync_state.m_ip.c_str());
    g->port = node->m_sync_state.m_main_port;
    g->cport = node->m_sync_state.m_cluster_port;
    g->flags = node->m_sync_state.m_flags;
    g->state = node->m_state;
    g->notused1 = 0;

    return true;
}
