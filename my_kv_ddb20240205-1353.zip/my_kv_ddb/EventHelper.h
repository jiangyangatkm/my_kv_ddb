#ifndef EVENTHELPER_H
#define EVENTHELPER_H

#pragma once

#include <sys/socket.h>
#include "EventLoop.h"

class EventHelper
{
    EventHelper() = delete;
    EventHelper(EventHelper&) = delete;
    ~EventHelper() = delete;
public:
    static void PushEvent(EventLoop *eloop, int id, EventDataBase *edata);
    static void PushAcceptEvent(
        EventLoop * eloop, int sfd, char *source, sockaddr * addr, socklen_t addr_len, void *data);
    static void PushReadEvent(
        EventLoop * eloop, int sfd, char *source, void * sock_buf);
    static void PushReadErrorEvent(
        EventLoop * eloop, int sfd, char *source, void * sock_buf, int error);
    static void PushWriteErrorEvent(
        EventLoop * eloop, int sfd, char *source, void * sock_buf, int error);
    
    static void PushTimeoutEvent(EventLoop *eloop, int id, long long timeout, EventDataBase *edata);
    static void PushTimerEvent(EventLoop * eloop, int t_id, long long timeout);
    static void PushDelayEvent(EventLoop * eloop, void *data, long long timeout);

private:
    static DdbEvent *create_ddb_event(int id, EventDataBase *data);
    static void PushErrorEvent(
        EventLoop * eloop, int event_id, int sfd, char *source, void * sock_buf, int error);
};

#endif