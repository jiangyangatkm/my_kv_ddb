#ifndef CLUSTERNODE_H
#define CLUSTERNODE_H

#pragma once

#include <string>
#include <unordered_set>

#include "SocketBufferPool.h"
#include "ClusterMsg.h"

/* Cluster node flags and macros. */
#define CLUSTER_NODE_MASTER 1     /* The node is a master */
#define CLUSTER_NODE_SLAVE 2      /* The node is a slave */
// #define CLUSTER_NODE_PFAIL 4      /* Failure? Need acknowledge */
// #define CLUSTER_NODE_FAIL 8       /* The node is believed to be malfunctioning */
// 16
#define CLUSTER_NODE_HANDSHAKE 32 /* We have still to exchange the first ping */
#define CLUSTER_NODE_NOADDR   64  /* We don't know the address of this node */
#define CLUSTER_NODE_MEET 128     /* Send a MEET message to this node */
#define CLUSTER_NODE_MIGRATE_TO 256 /* Master eligible for replica migration. */
#define CLUSTER_NODE_NOFAILOVER 512 /* Slave will not try to failover. */

#define CLUSTER_INVALID_TIME -1

typedef long long mstime_t; /* millisecond time type. */
typedef long long ustime_t; /* microsecond time type. */

enum ClusterNodeState { S_NORMAL = 0, S_PFAIL, S_FAIL };

using UShortSet = std::unordered_set<unsigned short>;
using StrSet = std::unordered_set<std::string>;

class DdbServer;
class ClusterNode;

class ClusterSyncState
{
public:
    std::string m_ip;
    unsigned short m_main_port;
    unsigned short m_cluster_port;

    long long m_repl_offset;
    std::string m_master_name;
    int m_slave_count;
    unsigned int m_mac;

    UShortSet *m_slots_set; // 优化本节点同步状态的生成,
                            // 直接使用DdbServer.m_slots_set的地址
    unsigned short m_flags;

    unsigned int m_votes_count; // 从节点参与选举时获得的选票数

    ClusterSyncState() 
    : m_slots_set(nullptr), m_main_port(0), m_cluster_port(0),
    m_repl_offset(0), m_slave_count(0), m_mac(0), m_flags(0), 
    m_votes_count(0)
    {}
};

class ClusterNode
{
    class MsgBlock;
    enum ReadState { READ_HEAD = 1, READ_DATA = 2};
public:
    ClusterNode(DdbServer *server, int sfd, SocketBuffer *buffer);
    ~ClusterNode();
public:
    int GetFd() { return m_sfd; }
    unsigned short GetPort() { return m_sync_state.m_cluster_port; }
    ClusterNodeState GetState() { return m_state; }
    std::string GetName();
    std::string GetClusterName();
    std::string GetMasterName() { return m_sync_state.m_master_name; }
    SocketBuffer *GetBuffer() { return m_in_buffer; }
    int GetFlags() { return m_sync_state.m_flags; }
    mstime_t GetPingSent() const { return m_ping_sent; }
    void SetPingSent(mstime_t new_time) { m_ping_sent = new_time; }
    mstime_t GetPongReceived() const { return m_pong_received; }
    void SetPongReceived(mstime_t new_time) { m_pong_received = new_time; }
    bool IsHandshaking() { return m_is_handshaking; }
    bool IsValid() { return m_is_valid; }
    bool IsSlotsChanged() { return m_is_slots_changed; }
    void SetSlotsChanged() { m_is_slots_changed = true; }
    void SetClusterAddress(std::string ip, unsigned short port);
    bool IsClient() { return m_is_client; }
    void SetAsClient() { m_is_client = true; }
    bool IsNeedAdditionalPing();
    bool IsVoted() { return m_is_voted; }
    void SetVotedState(bool is_voted) { m_is_voted = is_voted; }
    unsigned int GetVotesCount() { return m_sync_state.m_votes_count; }
    void ResetVotesCount() { m_sync_state.m_votes_count = 0; }
    bool IsMaster();
    void IncreaseEpoch() { m_epoch++; }
    int GetEpoch() { return m_epoch; }

    void DoRead();
    void DoReadError();
    void DoCron();
    void DoPingCheck();
    void Ping();
    void Pong();
    void Meet();
    void SendFailover(int msg_type, std::string name, int epoch);
    void SendFail(std::string name);

    std::string GetInfo();
    std::string GetInfoDetail();
private:
    void ping(int msg_type, int flags = 0);
    void send_msg(MsgBlock *block, int sfd);

    int process_clustermsg(clusterMsg *msg);
    int process_ping(clusterMsg *msg);
    int process_fail(clusterMsg *msg);
    int process_failover(clusterMsg *msg);
    int process_failover_request(clusterMsg *msg, ClusterNode *fnode);
    int process_failover_ack(clusterMsg *msg, ClusterNode *fnode);
    int process_failover_finish(clusterMsg *msg, ClusterNode *fnode);
    int process_failover_revote(clusterMsg *msg, ClusterNode *fnode);
    int process_gossip(clusterMsg *msg);

    int verify_message(clusterMsg *msg);
    void update_node_state(clusterMsg *msg);
    void update_slots(clusterMsg *msg);
    void send_read_error_event();
    void send_read_event();

    void add_pfail_report(std::string name);
    void remove_pfail_report(std::string name);
    void set_fail();
    void send_fail_to_all(std::string name);
    void send_failover_finish_to_all(ClusterNode *node);
    ClusterNode *get_fail_node(std::string name);
    // debug
    std::string get_slots_info();
private:
    DdbServer *m_server;

    int m_sfd;
    SocketBuffer *m_in_buffer;
    bool m_is_valid;

    // 节点基本状态，normal/pfail/fail
    // 该状态不是由对面节点发出的，而是通过
    // 本节点通过ping操作来评价的
    ClusterNodeState m_state;
    // 同步信息
    ClusterSyncState m_sync_state;

    // 部分标志
    bool m_is_handshaking;
    bool m_is_slots_changed;
    bool m_is_client;
    // 事件时间记录
    mstime_t m_ctime;           // 本节点创建时间
    mstime_t m_ping_sent;      /* Unix time we sent latest ping */
    mstime_t m_pong_received;  /* Unix time we received the pong */
    mstime_t m_data_received;  /* Unix time we received any data */
    mstime_t m_fail_time;      /* Unix time when FAIL flag was set */
    mstime_t m_ping_delay;

    clusterMsg m_recv_head;
    char *m_recv_data_buf;
    ReadState m_read_state;
    int m_res_data_count;
    int m_read_data_count;

    // 故障转移相关
    StrSet m_pfail_reports; // 将本节点标记为pfail的节点名称集合
    bool m_is_voted; // 记录针对ClusterNode(已故障)替换的选票有没有给出
    int m_epoch; // 成为Fail节点后，所经历的针对该节点的投票轮数

    // debug
    // int d_last_ping_size;
    // mstime_t d_pong_sent;
    // mstime_t d_ping_received;

    class MsgBlock {
    public:
        MsgBlock(ClusterNode *node, int msg_type, int msg_len);
        ~MsgBlock();
    public:
        clusterMsgData *GetMsgData() { return m_msg->data; }
        clusterMsg *GetMsg() { return m_msg; }
        int SendData(int sfd);
        bool SetGossip(int i, ClusterNode *node);
        int GetTotalLen() { return m_tot_len; }
    private:
        char *m_buf;
        int m_msg_len;
        int m_tot_len;
        ClusterNode *m_node;
        clusterMsg *m_msg;
    };
};

struct NodeTimeCompare {
    bool operator()(const ClusterNode * l, const ClusterNode * r) const
    {
        if(l->GetPingSent() < r->GetPingSent()) {
            return true;
        }
        else if(l->GetPingSent() == r->GetPingSent()) {
            return l < r;
        }
        else {
            return false;
        }
    }
};

#endif