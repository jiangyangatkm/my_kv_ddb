#include "EventHelper.h"

#include <string.h>
#include "EventData.h"

void EventHelper::PushEvent(EventLoop *eloop, int id, EventDataBase *edata)
{
    DdbEvent *event = create_ddb_event(id, edata);
    eloop->PushEvent(event);
}

void EventHelper::PushAcceptEvent(
    EventLoop *eloop, int sfd, char *source, sockaddr *addr, socklen_t addr_len, void *data)
{
    SockAcceptData * edata = new SockAcceptData;
    edata->sfd = sfd;
    edata->server_name = source;
    memcpy(&edata->addr, addr, sizeof(sockaddr));
    edata->addr_len = addr_len;
    edata->data = data;

    DdbEvent *event = create_ddb_event(KV_DDB_EVENT_SOCKET_ACCEPTED, edata);
    eloop->PushEvent(event);
}

void EventHelper::PushReadEvent(
    EventLoop *eloop, int sfd, char *source, void *sock_buf)
{
    SockReadData * edata = new SockReadData;
    edata->sfd = sfd;
    edata->server_name = source;
    edata->data = sock_buf;

    DdbEvent *event = create_ddb_event(KV_DDB_EVENT_SOCKET_READ, edata);
    eloop->PushEvent(event);
}

void EventHelper::PushReadErrorEvent(
    EventLoop *eloop, int sfd, char *source, void *sock_buf, int error)
{
    PushErrorEvent(eloop, KV_DDB_EVENT_SOCKET_READ_ERROR, sfd, source, sock_buf, error);
}

void EventHelper::PushWriteErrorEvent(
    EventLoop *eloop, int sfd, char *source, void *sock_buf, int error)
{
    PushErrorEvent(eloop, KV_DDB_EVENT_SOCKET_WRITE_ERROR, sfd, source, sock_buf, error);
}

void EventHelper::PushTimeoutEvent(
    EventLoop *eloop, int id, long long timeout, EventDataBase *edata)
{
    DdbTimeEvent *event = new DdbTimeEvent;
    event->id = id;
    event->timeout = timeout;
    event->data = edata;
    eloop->PushTimeEvent(event);
}

void EventHelper::PushTimerEvent(EventLoop *eloop, int t_id, long long timeout)
{
    TimerData *edata = new TimerData;
    edata->timer_id = t_id;

    PushTimeoutEvent(eloop, KV_DDB_EVENT_TIMER_TIMEOUT, timeout, edata);
    // DdbTimeEvent *event = new DdbTimeEvent;
    // event->id = KV_DDB_EVENT_TIMER_TIMEOUT;
    // event->timeout = timeout;
    // event->data = edata;
    // eloop->PushTimeEvent(event);
}

void EventHelper::PushDelayEvent(EventLoop *eloop, void *data, long long timeout)
{
    DelayData *edata = new DelayData;
    edata->data = data;
    PushTimeoutEvent(eloop, KV_DDB_EVENT_DELAY_TIMEOUT, timeout, edata);
}

DdbEvent *EventHelper::create_ddb_event(int id, EventDataBase *data)
{
    DdbEvent *event = new DdbEvent;
    event->id = id;
    event->data = data;
    return event;
}

void EventHelper::PushErrorEvent(
    EventLoop *eloop, int event_id, int sfd, char *source, void *sock_buf, int error)
{
    SockErrorData * edata = new SockErrorData;
    edata->sfd = sfd;
    edata->server_name = source;
    edata->data = sock_buf;
    edata->error_code = error;

    DdbEvent *event = create_ddb_event(event_id, edata);
    eloop->PushEvent(event);
}
